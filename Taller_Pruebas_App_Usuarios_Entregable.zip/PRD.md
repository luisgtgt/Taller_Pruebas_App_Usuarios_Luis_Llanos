# Documento de Requisitos del Producto (PRD) — App de Usuarios

## 1. Descripción General del Proyecto
**App de Usuarios** es una plataforma integral de autenticación y gestión de usuarios basada en una arquitectura desacoplada que consta de:
* **Backend (API REST)**: Desarrollada en Node.js 22+, Express y MongoDB (Mongoose), con autenticación mediante JSON Web Tokens (JWT) y cifrado de contraseñas con bcrypt.
* **Frontend (Web)**: Desarrollada en Vue 3 (Composition API), Vite y Vue Router, con componentes de interfaz accesibles y atributos estándar `data-test`.

---

## 2. Roles y Control de Acceso
El sistema implementa Control de Acceso Basado en Roles (RBAC) con dos roles:
1. **`admin` (Administrador)**:
   * Acceso total a la administración de usuarios (listado, búsqueda, creación, edición, borrado lógico).
   * Visualización y edición de su propio perfil.
2. **`usuario` (Usuario Estándar)**:
   * Acceso exclusivo a su propio perfil (actualizar nombre/email y cambio de contraseña).
   * Restringido el acceso a rutas administrativas (`/usuarios`), con redirección automática a `/perfil`.

---

## 3. Cuentas de Prueba (Datos Semilla / Seed)
Base de datos de pruebas inicializada mediante `npm run seed`:
* **Administrador**:
  * Email: `admin@demo.com`
  * Contraseña: `Admin123!`
  * Rol: `admin`
* **Usuario estándar**:
  * Email: `ana@demo.com`
  * Contraseña: `Usuario123`
  * Rol: `usuario`
* **Otros usuarios**:
  * `luis@demo.com` / `Usuario123` (rol: `usuario`)
  * `marta@demo.com` / `Usuario123` (rol: `admin`)
  * `pedro@demo.com` / `Usuario123` (rol: `usuario`, inactivo / `estado: false`)

---

## 4. Requisitos y Reglas de Negocio de la API

### 4.1. Autenticación (`/api/auth`)
* **`POST /api/auth/registro`**:
  * Registro público de cuentas.
  * Por seguridad, el rol asignado **siempre es `usuario`**, ignorando si el cliente intenta enviar `rol: admin`.
  * La respuesta debe retornar código HTTP 201, token JWT y datos del usuario sin el campo `password`.
* **`POST /api/auth/login`**:
  * Valida credenciales contra la base de datos con bcrypt.
  * Si el email no existe o la contraseña es incorrecta, devuelve código HTTP 401 con el mensaje genérico: `"Credenciales inválidas"`.
  * Si el usuario se encuentra en borrado lógico (`estado: false`), devuelve código HTTP 401 con el mensaje: `"Usuario desactivado"`.
  * Si es correcto, devuelve código HTTP 200, JWT y objeto de usuario con `uid`.
* **`GET /api/auth/perfil`**:
  * Requiere encabezado `x-token`.
  * Sin token o token inválido/expirado: responde 401.
  * Token válido: responde 200 con la información del usuario autenticado.
* **`PUT /api/auth/perfil`**:
  * Permite actualizar nombre y email del usuario autenticado.
  * Si el email ya pertenece a otro usuario registrado, responde 400.
* **`PUT /api/auth/password`**:
  * Requiere `passwordActual` y `passwordNueva`.
  * Si `passwordActual` no coincide con el hash almacenado, responde 400 con `"La contraseña actual no es correcta"`.
  * Si `passwordNueva` es igual a `passwordActual`, responde 400 con `"La nueva contraseña debe ser distinta de la actual"`.
  * En éxito, responde 200 y hashea la nueva clave.

### 4.2. CRUD de Usuarios (`/api/usuarios`)
Todas las operaciones requieren token con rol `admin`. Si se envía un token de rol `usuario`, la API responde 403 (`"No tiene permisos para esto"`).
* **`GET /api/usuarios`**:
  * Lista usuarios activos (`estado: true`). Los eliminados lógicamente nunca aparecen.
  * Parámetros de consulta: `buscar`, `rol`, `pagina` (mínimo 1), `limite` (mínimo 1, máximo 50).
  * Si `limite > 50`, responde 400.
  * Retorna estructura paginada: `{ total, pagina, limite, totalPaginas, usuarios }`.
* **`GET /api/usuarios/:id`**:
  * Si el `id` no es un MongoId válido, responde 400 con `"Id no válido"`.
  * Si el usuario no existe o `estado: false`, responde 404 con `"Usuario no encontrado"`.
* **`POST /api/usuarios`**:
  * Permite al admin dar de alta usuarios especificando rol (`admin` o `usuario`).
  * Hashea automáticamente la contraseña antes de persistir. Responde 201.
* **`PUT /api/usuarios/:id`**:
  * Actualización parcial de datos. Si se envía `password` vacía, se ignora y se preserva el hash existente sin re-hashear.
  * **Regla de negocio crítica**: Un administrador **no puede modificar su propio rol** (responde 400 con `"No puedes cambiar tu propio rol"`).
* **`DELETE /api/usuarios/:id`**:
  * **Regla de negocio crítica**: Un administrador **no puede eliminarse a sí mismo** (responde 400 con `"No puedes eliminar tu propia cuenta"`).
  * **Borrado lógico**: No destruye el registro físico de la base de datos, sino que cambia su campo a `estado: false`. A partir de ese momento, el usuario no se lista y se le bloquea el inicio de sesión (401).

---

## 5. Validación de Datos (Frontend y Backend)
* **Nombre**: Obligatorio, entre 2 y 60 caracteres.
* **Email**: Obligatorio, formato válido (`user@domain.com`), único en el sistema.
* **Contraseña**:
  * Mínimo 8 y máximo 64 caracteres.
  * Al menos una letra mayúscula (`[A-Z]`).
  * Al menos una letra minúscula (`[a-z]`).
  * Al menos un número (`[0-9]`).

---

## 6. Selectores de Interfaz (Atributos data-test)
* Login: `login-email`, `login-password`, `login-submit`, `login-form`.
* Registro: `register-name`, `register-email`, `register-password`, `register-confirmation`, `register-submit`.
* Perfil: `profile-name`, `profile-email`, `profile-submit`, `password-current`, `password-new`, `password-confirmation`, `password-submit`, `profile-role`.
* Tabla y Gestión: `users-search`, `users-role-filter`, `user-row`, `user-edit`, `user-delete`, `users-new`, `confirm-accept`, `confirm-cancel`.
* Paginación y Notificaciones: `pagination-info`, `pagination-prev`, `pagination-next`, `toast`, `alert`.
