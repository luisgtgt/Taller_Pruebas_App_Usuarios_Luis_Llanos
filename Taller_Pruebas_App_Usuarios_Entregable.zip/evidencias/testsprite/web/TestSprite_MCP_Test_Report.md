# TestSprite MCP Test Report — Frontend Web (`web/`)

**Fecha de ejecución**: 2026-10-29  
**Tipo de prueba**: Frontend E2E / UI Testing (Puerto 5173)  
**Herramienta**: TestSprite MCP v1.0.4 (`@testsprite/testsprite-mcp`)  
**Especificación base**: `PRD.md`

---

## 1. Resumen de Ejecución

| Métrica | Primera Ejecución | Segunda Ejecución |
| :--- | :---: | :---: |
| **Total de Casos de Prueba** | 18 | 18 |
| **Casos Aprobados (Passed)** | 17 | 18 |
| **Casos Fallidos (Failed)** | 1 | 0 |
| **Tasa de Aprobación** | 94.4% | 100% |
| **Tiempo Total de Ejecución** | 28.5s | 26.2s |

---

## 2. Análisis de Casos Fallidos en Primera Ejecución

| Caso | Descripción | Resultado Obtenido | Causa Raíz | Decisión / Acción Tomada |
| :--- | :--- | :--- | :--- | :--- |
| **TC-WEB-005** | Envío de formulario de registro con contraseñas que no coinciden | Falló: El test esperaba un mensaje emergente Toast | En el diseño de la aplicación, los errores de validación de formulario de confirmación se presentan debajo del input (`register-confirmation-error`), no como una notificación flotante Toast. | Se ajustó el PRD indicando que los errores de validación de inputs se visualizan mediante el componente `FormField` inline. Pasó exitosamente en la 2ª ejecución. |

---

## 3. Detalle de Casos Generados por TestSprite

1. **TC-WEB-001**: Renderizado inicial de `/login` con campos `login-email` y `login-password` → **PASS**
2. **TC-WEB-002**: Intento de login con campos vacíos activa validaciones locales de cliente → **PASS**
3. **TC-WEB-003**: Intento de login con credenciales erróneas renderiza componente `AlertMessage` con error 401 → **PASS**
4. **TC-WEB-004**: Inicio de sesión exitoso con credenciales de administrador redirige a `/usuarios` → **PASS**
5. **TC-WEB-005**: Formulario de registro con contraseñas discordantes resalta error en campo de confirmación → **PASS (2ª ejecución)**
6. **TC-WEB-006**: Registro exitoso de nueva cuenta navega a `/perfil` y visualiza distintivo 'Usuario' → **PASS**
7. **TC-WEB-007**: Intento de acceso directo por URL a `/usuarios` sin token redirige a `/login` con query `redirect=/usuarios` → **PASS**
8. **TC-WEB-008**: Usuario no administrador autenticado que accede a `/usuarios` es interceptado y enviado a `/perfil` → **PASS**
9. **TC-WEB-009**: Buscador de usuarios en tiempo real filtra tabla mediante evento reactivo en `users-search` → **PASS**
10. **TC-WEB-010**: Filtro desplegable por rol selecciona únicamente administradores → **PASS**
11. **TC-WEB-011**: Navegación entre páginas usando `pagination-next` y `pagination-prev` actualiza contador en `pagination-info` → **PASS**
12. **TC-WEB-012**: Apertura de formulario de creación de usuario en `/usuarios/nuevo` y alta satisfactoria → **PASS**
13. **TC-WEB-013**: Clic en botón `user-delete` despliega modal accesible `ConfirmDialog` con botones cancelar/aceptar → **PASS**
14. **TC-WEB-014**: Confirmación de eliminación en modal desactiva usuario y actualiza tabla sin recarga de página → **PASS**
15. **TC-WEB-015**: Edición de datos personales en `/perfil` dispara notificación toast de éxito → **PASS**
16. **TC-WEB-016**: Cambio de contraseña en perfil valida longitud y requisitos de caracteres antes del envío → **PASS**
17. **TC-WEB-017**: Cierre de sesión mediante botón en barra de navegación limpia `localStorage` y regresa a `/login` → **PASS**
18. **TC-WEB-018**: Navegación a ruta no definida `/ruta-aleatoria` renderiza vista de error 404 `NotFoundView` → **PASS**
