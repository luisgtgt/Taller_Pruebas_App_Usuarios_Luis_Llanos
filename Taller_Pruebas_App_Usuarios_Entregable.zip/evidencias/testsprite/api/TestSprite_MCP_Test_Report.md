# TestSprite MCP Test Report — Backend API (`api/`)

**Fecha de ejecución**: 2026-10-29  
**Tipo de prueba**: Backend API Testing (Puerto 3000)  
**Herramienta**: TestSprite MCP v1.0.4 (`@testsprite/testsprite-mcp`)  
**Especificación base**: `PRD.md`

---

## 1. Resumen de Ejecución

| Métrica | Primera Ejecución | Segunda Ejecución (Tras Aclaración en PRD) |
| :--- | :---: | :---: |
| **Total de Casos de Prueba** | 24 | 24 |
| **Casos Aprobados (Passed)** | 23 | 24 |
| **Casos Fallidos (Failed)** | 1 | 0 |
| **Tasa de Aprobación** | 95.8% | 100% |
| **Tiempo Total de Ejecución** | 12.4s | 11.8s |

---

## 2. Análisis de Casos Fallidos en Primera Ejecución

| Caso | Descripción | Resultado Obtenido | Causa Raíz | Decisión / Acción Tomada |
| :--- | :--- | :--- | :--- | :--- |
| **TC-API-007** | Intento de cambio de rol del propio administrador logueado a rol usuario mediante `PUT /api/usuarios/:id` | Falló: Esperaba código HTTP 200 | Requisito de negocio mal interpretado por el agente IA. La regla de la aplicación restringe que el admin degrade su propia cuenta devolviendo 400. | Se clarificó la regla de restricción propia en `PRD.md`. No se modificó el código fuente. En la 2ª ejecución pasó exitosamente esperando 400. |

---

## 3. Detalle de Casos Generados por TestSprite

1. **TC-API-001**: `GET /api/health` — Verifica respuesta de salud del servidor (200 OK) → **PASS**
2. **TC-API-002**: `POST /api/auth/registro` — Registro con payload válido crea usuario con rol usuario (201 Created) → **PASS**
3. **TC-API-003**: `POST /api/auth/registro` — Intento de inyectar rol 'admin' es ignorado por la API (201 Created con rol 'usuario') → **PASS**
4. **TC-API-004**: `POST /api/auth/registro` — Email duplicado retorna 400 y mensaje en array de errores → **PASS**
5. **TC-API-005**: `POST /api/auth/registro` — Validación de política de contraseñas robustas (400 Bad Request) → **PASS**
6. **TC-API-006**: `POST /api/auth/login` — Autenticación exitosa con credenciales válidas (200 OK, JWT presente) → **PASS**
7. **TC-API-007**: `PUT /api/usuarios/:id` — Admin intentando modificar su propio rol a 'usuario' (400 Bad Request) → **PASS (2ª ejecución)**
8. **TC-API-008**: `POST /api/auth/login` — Contraseña incorrecta devuelve mensaje genérico 'Credenciales inválidas' (401 Unauthorized) → **PASS**
9. **TC-API-009**: `POST /api/auth/login` — Usuario desactivado (`estado: false`) bloqueado para login (401 Unauthorized) → **PASS**
10. **TC-API-010**: `GET /api/auth/perfil` — Consulta de perfil sin cabecera `x-token` (401 Unauthorized) → **PASS**
11. **TC-API-011**: `GET /api/auth/perfil` — Consulta de perfil con token válido (200 OK con datos de sesión) → **PASS**
12. **TC-API-012**: `PUT /api/auth/perfil` — Actualización de nombre y email propios (200 OK) → **PASS**
13. **TC-API-013**: `PUT /api/auth/password` — Cambio de clave con contraseña actual incorrecta (400 Bad Request) → **PASS**
14. **TC-API-014**: `PUT /api/auth/password` — Nueva clave idéntica a la anterior es rechazada (400 Bad Request) → **PASS**
15. **TC-API-015**: `PUT /api/auth/password` — Actualización exitosa de contraseña y posterior login con la nueva clave (200 OK) → **PASS**
16. **TC-API-016**: `GET /api/usuarios` — Acceso denegado con token de rol 'usuario' (403 Forbidden) → **PASS**
17. **TC-API-017**: `GET /api/usuarios` — Acceso concedido con token de rol 'admin' (200 OK con estructura paginada) → **PASS**
18. **TC-API-018**: `GET /api/usuarios?limite=51` — Validación de rango superior de límite de paginación (400 Bad Request) → **PASS**
19. **TC-API-019**: `GET /api/usuarios?buscar=ana&rol=usuario` — Filtrado combinado por texto y rol (200 OK) → **PASS**
20. **TC-API-020**: `GET /api/usuarios/:id` — ID con formato hexadecimal no MongoId (400 Bad Request) → **PASS**
21. **TC-API-021**: `POST /api/usuarios` — Creación administrativa de usuario y verificación de cifrado bcrypt (201 Created) → **PASS**
22. **TC-API-022**: `DELETE /api/usuarios/:id` — Admin intentando autoeliminarse (400 Bad Request) → **PASS**
23. **TC-API-023**: `DELETE /api/usuarios/:id` — Borrado lógico de usuario; exclusión de listado y bloqueo de login (200 OK) → **PASS**
24. **TC-API-024**: `POST /api/auth/login` — Body JSON sintácticamente mal formado (400 Bad Request) → **PASS**
