import { describe, it, expect, vi, beforeEach } from "vitest";
import { validarRol } from "../../middlewares/validar-rol.js";
import { validarCampos } from "../../middlewares/validar-campos.js";
import { validationResult } from "express-validator";

vi.mock("express-validator", () => ({
  validationResult: vi.fn(),
}));

describe("Middlewares Unitarios", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("validarRol", () => {
    it("responde 500 si req.usuario no existe", () => {
      const middleware = validarRol("admin");
      const req = {};
      const res = {
        status: vi.fn().mockReturnThis(),
        json: vi.fn(),
      };
      const next = vi.fn();

      middleware(req, res, next);

      expect(res.status).toHaveBeenCalledWith(500);
      expect(res.json).toHaveBeenCalledWith({ error: "Se requiere validarJWT primero" });
      expect(next).not.toHaveBeenCalled();
    });

    it("responde 403 si el rol del usuario no está permitido", () => {
      const middleware = validarRol("admin");
      const req = { usuario: { rol: "usuario" } };
      const res = {
        status: vi.fn().mockReturnThis(),
        json: vi.fn(),
      };
      const next = vi.fn();

      middleware(req, res, next);

      expect(res.status).toHaveBeenCalledWith(403);
      expect(res.json).toHaveBeenCalledWith({ error: "No tiene permisos para esto" });
      expect(next).not.toHaveBeenCalled();
    });

    it("llama a next() si el rol está permitido", () => {
      const middleware = validarRol("admin", "moderador");
      const req = { usuario: { rol: "admin" } };
      const res = {
        status: vi.fn().mockReturnThis(),
        json: vi.fn(),
      };
      const next = vi.fn();

      middleware(req, res, next);

      expect(next).toHaveBeenCalledTimes(1);
      expect(res.status).not.toHaveBeenCalled();
    });
  });

  describe("validarCampos", () => {
    it("llama a next() cuando no hay errores de validación", () => {
      validationResult.mockReturnValue({
        isEmpty: () => true,
        array: () => [],
      });

      const req = {};
      const res = {
        status: vi.fn().mockReturnThis(),
        json: vi.fn(),
      };
      const next = vi.fn();

      validarCampos(req, res, next);

      expect(next).toHaveBeenCalledTimes(1);
      expect(res.status).not.toHaveBeenCalled();
    });

    it("responde 400 con lista de errores cuando validationResult contiene fallos", () => {
      validationResult.mockReturnValue({
        isEmpty: () => false,
        array: () => [{ path: "email", msg: "Email no válido" }],
      });

      const req = {};
      const res = {
        status: vi.fn().mockReturnThis(),
        json: vi.fn(),
      };
      const next = vi.fn();

      validarCampos(req, res, next);

      expect(res.status).toHaveBeenCalledWith(400);
      expect(res.json).toHaveBeenCalledWith({
        errores: [{ path: "email", msg: "Email no válido" }],
      });
      expect(next).not.toHaveBeenCalled();
    });
  });
});
