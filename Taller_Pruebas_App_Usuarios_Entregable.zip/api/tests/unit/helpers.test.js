import { describe, it, expect } from "vitest";
import jwt from "jsonwebtoken";
import { generarJWT } from "../../helpers/generar-jwt.js";
import { esRolValido, emailExiste } from "../../helpers/db-validators.js";
import Usuario from "../../models/usuario.js";

describe("Helpers Unitarios", () => {
  describe("generarJWT", () => {
    it("el token contiene uid y rol en el payload", () => {
      const usuarioMock = {
        id: "60c72b2f9b1d8b2bad8f4111",
        rol: "admin",
      };

      const token = generarJWT(usuarioMock);
      expect(typeof token).toBe("string");

      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      expect(decoded.uid).toBe(usuarioMock.id);
      expect(decoded.rol).toBe(usuarioMock.rol);
    });
  });

  describe("esRolValido", () => {
    it("retorna true para roles existentes 'admin' y 'usuario'", () => {
      expect(esRolValido("admin")).toBe(true);
      expect(esRolValido("usuario")).toBe(true);
    });

    it("lanza error para roles no permitidos", () => {
      expect(() => esRolValido("superadmin")).toThrow(
        "El rol debe ser uno de: admin, usuario"
      );
      expect(() => esRolValido("invitado")).toThrow(
        "El rol debe ser uno de: admin, usuario"
      );
    });
  });

  describe("emailExiste", () => {
    it("no lanza error si el email no está registrado", async () => {
      await expect(
        emailExiste("no-existe@demo.com")
      ).resolves.toBeUndefined();
    });

    it("lanza error si el email ya existe para otro usuario", async () => {
      const usuario = new Usuario({
        nombre: "Test User",
        email: "existente@demo.com",
        password: "Password123!",
        rol: "usuario",
      });
      await usuario.save();

      await expect(
        emailExiste("existente@demo.com", "otro_id_diferente")
      ).rejects.toThrow("Ese email ya está registrado");
    });

    it("no lanza error si el email existe pero es del mismo usuario (idPropio)", async () => {
      const usuario = new Usuario({
        nombre: "Propio User",
        email: "propio@demo.com",
        password: "Password123!",
        rol: "usuario",
      });
      await usuario.save();

      await expect(
        emailExiste("propio@demo.com", usuario.id)
      ).resolves.toBeUndefined();
    });
  });
});
