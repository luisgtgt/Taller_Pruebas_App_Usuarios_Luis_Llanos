import { describe, it, expect } from "vitest";
import Usuario from "../../models/usuario.js";
import bcrypt from "bcryptjs";

describe("Modelo Usuario", () => {
  it("toJSON no devuelve password ni _id, y renombra a uid", async () => {
    const usuario = new Usuario({
      nombre: "Juan Perez",
      email: "juan@test.com",
      password: "Password123!",
      rol: "usuario",
    });
    await usuario.save();

    const json = usuario.toJSON();
    expect(json.password).toBeUndefined();
    expect(json._id).toBeUndefined();
    expect(json.__v).toBeUndefined();
    expect(json.uid).toBeDefined();
    expect(json.email).toBe("juan@test.com");
  });

  it("hashea la contraseña automáticamente al guardar con bcrypt", async () => {
    const rawPass = "Segura123!";
    const usuario = new Usuario({
      nombre: "Carlos Gomez",
      email: "carlos@test.com",
      password: rawPass,
      rol: "usuario",
    });
    await usuario.save();

    expect(usuario.password).not.toBe(rawPass);
    expect(bcrypt.compareSync(rawPass, usuario.password)).toBe(true);
  });

  it("no vuelve a hashear la contraseña si no fue modificada en save()", async () => {
    const usuario = new Usuario({
      nombre: "Maria Lopez",
      email: "maria@test.com",
      password: "Password123!",
      rol: "usuario",
    });
    await usuario.save();
    const hashOriginal = usuario.password;

    usuario.nombre = "Maria Lopez Editada";
    await usuario.save();

    expect(usuario.password).toBe(hashOriginal);
  });

  it("validarPassword retorna true si coincide y false si no coincide", async () => {
    const usuario = new Usuario({
      nombre: "Laura Test",
      email: "laura@test.com",
      password: "Password123!",
      rol: "usuario",
    });
    await usuario.save();

    expect(usuario.validarPassword("Password123!")).toBe(true);
    expect(usuario.validarPassword("PasswordIncorrecta")).toBe(false);
  });
});
