import Usuario from "../models/usuario.js";
import { generarJWT } from "../helpers/generar-jwt.js";

let userCounter = 1;

export const crearUsuario = async (datosExtra = {}) => {
  const index = userCounter++;
  const datosPorDefecto = {
    nombre: `Usuario ${index}`,
    email: `test_user_${index}_${Date.now()}_${Math.random().toString(36).substring(7)}@demo.com`,
    password: "Password123!",
    rol: "usuario",
    estado: true,
  };

  const usuario = new Usuario({ ...datosPorDefecto, ...datosExtra });
  await usuario.save();
  return usuario;
};

export const tokenUsuario = async (usuarioODatos = {}) => {
  if (usuarioODatos && usuarioODatos._id) {
    return generarJWT(usuarioODatos);
  }
  const usuario = await crearUsuario({ rol: "usuario", ...usuarioODatos });
  return generarJWT(usuario);
};

export const tokenAdmin = async (usuarioODatos = {}) => {
  if (usuarioODatos && usuarioODatos._id) {
    return generarJWT(usuarioODatos);
  }
  const admin = await crearUsuario({ rol: "admin", ...usuarioODatos });
  return generarJWT(admin);
};
