import { describe, it, expect } from "vitest";
import request from "supertest";
import app from "../../app.js";
import Usuario from "../../models/usuario.js";
import { crearUsuario, tokenAdmin, tokenUsuario } from "../helpers.js";

describe("CRUD de Usuarios (/api/usuarios)", () => {
  describe("GET /api/usuarios", () => {
    it("sin token responde 401", async () => {
      const res = await request(app).get("/api/usuarios");
      expect(res.status).toBe(401);
    });

    it("con token de usuario responde 403", async () => {
      const token = await tokenUsuario();
      const res = await request(app)
        .get("/api/usuarios")
        .set("x-token", token);

      expect(res.status).toBe(403);
      expect(res.body.error).toBe("No tiene permisos para esto");
    });

    it("con token de admin responde 200 con total, pagina, limite, totalPaginas y usuarios activos", async () => {
      const token = await tokenAdmin();
      await crearUsuario({ nombre: "Activo 1", email: "activo1@demo.com", estado: true });
      await crearUsuario({ nombre: "Inactivo 1", email: "inactivo1@demo.com", estado: false });

      const res = await request(app)
        .get("/api/usuarios")
        .set("x-token", token);

      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty("total");
      expect(res.body).toHaveProperty("pagina");
      expect(res.body).toHaveProperty("limite");
      expect(res.body).toHaveProperty("totalPaginas");
      expect(Array.isArray(res.body.usuarios)).toBe(true);
      // No debe contener el usuario con estado false
      const contieneInactivo = res.body.usuarios.some((u) => u.email === "inactivo1@demo.com");
      expect(contieneInactivo).toBe(false);
    });

    it("GET /?limite=51 responde 400 por límite fuera de rango", async () => {
      const token = await tokenAdmin();
      const res = await request(app)
        .get("/api/usuarios?limite=51")
        .set("x-token", token);

      expect(res.status).toBe(400);
      expect(res.body.errores).toBeDefined();
    });

    it("GET /?buscar=ana&rol=usuario responde 200 combinando búsqueda y rol", async () => {
      const token = await tokenAdmin();
      await crearUsuario({ nombre: "Ana Torres", email: "ana.torres@demo.com", rol: "usuario" });
      await crearUsuario({ nombre: "Ana Admin", email: "ana.admin@demo.com", rol: "admin" });
      await crearUsuario({ nombre: "Carlos Perez", email: "carlos@demo.com", rol: "usuario" });

      const res = await request(app)
        .get("/api/usuarios?buscar=ana&rol=usuario")
        .set("x-token", token);

      expect(res.status).toBe(200);
      expect(res.body.usuarios.length).toBe(1);
      expect(res.body.usuarios[0].nombre).toBe("Ana Torres");
    });
  });

  describe("GET /api/usuarios/:id", () => {
    it("con id mal formado (abc) responde 400 'Id no válido'", async () => {
      const token = await tokenAdmin();
      const res = await request(app)
        .get("/api/usuarios/abc")
        .set("x-token", token);

      expect(res.status).toBe(400);
      expect(res.body.errores.some((e) => e.msg === "Id no válido")).toBe(true);
    });

    it("con id válido que no existe responde 404 'Usuario no encontrado'", async () => {
      const token = await tokenAdmin();
      const idInexistente = "507f1f77bcf86cd799439011";
      const res = await request(app)
        .get(`/api/usuarios/${idInexistente}`)
        .set("x-token", token);

      expect(res.status).toBe(404);
      expect(res.body.error).toBe("Usuario no encontrado");
    });

    it("con id de usuario activo responde 200 con los datos del usuario", async () => {
      const token = await tokenAdmin();
      const usuario = await crearUsuario({ nombre: "Usuario Detalle", email: "detalle@demo.com" });

      const res = await request(app)
        .get(`/api/usuarios/${usuario.id}`)
        .set("x-token", token);

      expect(res.status).toBe(200);
      expect(res.body.email).toBe("detalle@demo.com");
      expect(res.body.uid).toBe(usuario.id);
    });

    it("con id de usuario inactivo (estado: false) responde 404", async () => {
      const token = await tokenAdmin();
      const usuario = await crearUsuario({ email: "borrado@demo.com", estado: false });

      const res = await request(app)
        .get(`/api/usuarios/${usuario.id}`)
        .set("x-token", token);

      expect(res.status).toBe(404);
      expect(res.body.error).toBe("Usuario no encontrado");
    });
  });

  describe("POST /api/usuarios", () => {
    it("admin crea usuario: responde 201 y la contraseña queda hasheada en la base de datos", async () => {
      const token = await tokenAdmin();
      const rawPassword = "AdminCreated123!";

      const res = await request(app)
        .post("/api/usuarios")
        .set("x-token", token)
        .send({
          nombre: "Creado Por Admin",
          email: "creado@demo.com",
          password: rawPassword,
          rol: "usuario",
        });

      expect(res.status).toBe(201);
      expect(res.body.email).toBe("creado@demo.com");
      expect(res.body.password).toBeUndefined();

      // Verificar en la BD que la contraseña está hasheada
      const usuarioEnBd = await Usuario.findOne({ email: "creado@demo.com" });
      expect(usuarioEnBd.password).not.toBe(rawPassword);
      expect(usuarioEnBd.validarPassword(rawPassword)).toBe(true);
    });
  });

  describe("PUT /api/usuarios/:id", () => {
    it("admin intenta cambiar su propio rol responde 400", async () => {
      const admin = await crearUsuario({
        nombre: "Admin Principal",
        email: "admin.propio@demo.com",
        rol: "admin",
      });
      const token = await tokenAdmin(admin);

      const res = await request(app)
        .put(`/api/usuarios/${admin.id}`)
        .set("x-token", token)
        .send({ rol: "usuario" });

      expect(res.status).toBe(400);
      expect(res.body.error).toBe("No puedes cambiar tu propio rol");
    });

    it("con password vacía no se cambia y el login sigue funcionando", async () => {
      const token = await tokenAdmin();
      const rawPassword = "PasswordOriginal123!";
      const usuario = await crearUsuario({
        email: "sinpass@demo.com",
        password: rawPassword,
      });

      const res = await request(app)
        .put(`/api/usuarios/${usuario.id}`)
        .set("x-token", token)
        .send({
          nombre: "Nuevo Nombre",
          password: "",
        });

      expect(res.status).toBe(200);

      // Comprobar que sigue iniciando sesión con la misma contraseña original
      const resLogin = await request(app)
        .post("/api/auth/login")
        .send({
          email: "sinpass@demo.com",
          password: rawPassword,
        });

      expect(resLogin.status).toBe(200);
    });

    it("actualiza usuario existente con éxito (200)", async () => {
      const token = await tokenAdmin();
      const usuario = await crearUsuario({
        nombre: "Antes",
        email: "antes@demo.com",
        rol: "usuario",
      });

      const res = await request(app)
        .put(`/api/usuarios/${usuario.id}`)
        .set("x-token", token)
        .send({
          nombre: "Despues",
          rol: "admin",
        });

      expect(res.status).toBe(200);
      expect(res.body.nombre).toBe("Despues");
      expect(res.body.rol).toBe("admin");
    });
  });

  describe("DELETE /api/usuarios/:id", () => {
    it("admin intenta eliminarse a sí mismo responde 400", async () => {
      const admin = await crearUsuario({
        nombre: "Admin Elim",
        email: "admin.elim@demo.com",
        rol: "admin",
      });
      const token = await tokenAdmin(admin);

      const res = await request(app)
        .delete(`/api/usuarios/${admin.id}`)
        .set("x-token", token);

      expect(res.status).toBe(400);
      expect(res.body.error).toBe("No puedes eliminar tu propia cuenta");
    });

    it("borrado lógico: deja de aparecer en el listado y ya no puede iniciar sesión (200)", async () => {
      const token = await tokenAdmin();
      const password = "Usuario123!";
      const usuario = await crearUsuario({
        email: "aborrar@demo.com",
        password,
      });

      const resDelete = await request(app)
        .delete(`/api/usuarios/${usuario.id}`)
        .set("x-token", token);

      expect(resDelete.status).toBe(200);
      expect(resDelete.body.mensaje).toBe("Usuario eliminado");

      // Comprobar que ya no aparece en el listado
      const resListado = await request(app)
        .get("/api/usuarios")
        .set("x-token", token);

      const existeEnListado = resListado.body.usuarios.some((u) => u.email === "aborrar@demo.com");
      expect(existeEnListado).toBe(false);

      // Comprobar que ya no puede iniciar sesión
      const resLogin = await request(app)
        .post("/api/auth/login")
        .send({
          email: "aborrar@demo.com",
          password,
        });

      expect(resLogin.status).toBe(401);
      expect(resLogin.body.error).toBe("Usuario desactivado");
    });

    it("eliminar usuario inexistente responde 404", async () => {
      const token = await tokenAdmin();
      const idInexistente = "507f1f77bcf86cd799439011";

      const res = await request(app)
        .delete(`/api/usuarios/${idInexistente}`)
        .set("x-token", token);

      expect(res.status).toBe(404);
      expect(res.body.error).toBe("Usuario no encontrado");
    });
  });
});
