import { describe, it, expect } from "vitest";
import request from "supertest";
import app from "../../app.js";
import { crearUsuario, tokenUsuario } from "../helpers.js";

describe("Endpoints Generales y Autenticación (/api/auth)", () => {
  describe("Rutas base y control de errores globales", () => {
    it("GET /api/health responde 200 con { status: 'ok' }", async () => {
      const res = await request(app).get("/api/health");
      expect(res.status).toBe(200);
      expect(res.body).toEqual({ status: "ok" });
    });

    it("GET /api/ruta-que-no-existe responde 404 en JSON", async () => {
      const res = await request(app).get("/api/ruta-inexistente-12345");
      expect(res.status).toBe(404);
      expect(res.body).toEqual({ error: "Ruta no encontrada" });
    });

    it("POST con body JSON mal formado responde 400 con mensaje descriptivo", async () => {
      const res = await request(app)
        .post("/api/auth/login")
        .set("Content-Type", "application/json")
        .send("{ email: 'invalido' "); // mal formado

      expect(res.status).toBe(400);
      expect(res.body.error).toBe("El cuerpo de la petición no es un JSON válido");
    });
  });

  describe("POST /api/auth/registro", () => {
    it("con datos válidos responde 201, devuelve token, rol 'usuario' aunque envíe 'admin', sin password", async () => {
      const res = await request(app)
        .post("/api/auth/registro")
        .send({
          nombre: "Nuevo Usuario",
          email: "nuevo@demo.com",
          password: "Password123!",
          rol: "admin", // Intentar forzar rol admin
        });

      expect(res.status).toBe(201);
      expect(res.body.token).toBeDefined();
      expect(res.body.usuario).toBeDefined();
      expect(res.body.usuario.rol).toBe("usuario");
      expect(res.body.usuario.password).toBeUndefined();
      expect(res.body.usuario.uid).toBeDefined();
    });

    it("con email ya registrado responde 400 con path email", async () => {
      await crearUsuario({ email: "duplicado@demo.com" });

      const res = await request(app)
        .post("/api/auth/registro")
        .send({
          nombre: "Otro Usuario",
          email: "duplicado@demo.com",
          password: "Password123!",
        });

      expect(res.status).toBe(400);
      expect(res.body.errores).toBeDefined();
      const errorEmail = res.body.errores.find((e) => e.path === "email");
      expect(errorEmail).toBeDefined();
      expect(errorEmail.msg).toBe("Ese email ya está registrado");
    });

    it("con contraseña sin mayúscula o con menos de 8 caracteres responde 400", async () => {
      const resCorta = await request(app)
        .post("/api/auth/registro")
        .send({
          nombre: "Test Pass",
          email: "testpass@demo.com",
          password: "Pass1",
        });

      expect(resCorta.status).toBe(400);
      expect(resCorta.body.errores).toBeDefined();

      const resSinMayuscula = await request(app)
        .post("/api/auth/registro")
        .send({
          nombre: "Test Pass 2",
          email: "testpass2@demo.com",
          password: "password123!",
        });

      expect(resSinMayuscula.status).toBe(400);
      expect(resSinMayuscula.body.errores).toBeDefined();
    });

    it("con nombre vacío responde 400", async () => {
      const res = await request(app)
        .post("/api/auth/registro")
        .send({
          nombre: "",
          email: "nombrevacio@demo.com",
          password: "Password123!",
        });

      expect(res.status).toBe(400);
      expect(res.body.errores.some((e) => e.path === "nombre")).toBe(true);
    });
  });

  describe("POST /api/auth/login", () => {
    it("con credenciales correctas responde 200 y devuelve token y usuario con uid", async () => {
      await crearUsuario({
        email: "loginexitoso@demo.com",
        password: "Password123!",
      });

      const res = await request(app)
        .post("/api/auth/login")
        .send({
          email: "loginexitoso@demo.com",
          password: "Password123!",
        });

      expect(res.status).toBe(200);
      expect(res.body.token).toBeDefined();
      expect(res.body.usuario.uid).toBeDefined();
      expect(res.body.usuario.email).toBe("loginexitoso@demo.com");
    });

    it("con contraseña incorrecta y email inexistente devuelve el mismo mensaje 'Credenciales inválidas' (401)", async () => {
      await crearUsuario({
        email: "existente@demo.com",
        password: "Password123!",
      });

      // Contraseña incorrecta
      const resPassIncorrecta = await request(app)
        .post("/api/auth/login")
        .send({
          email: "existente@demo.com",
          password: "PasswordErronea123!",
        });

      expect(resPassIncorrecta.status).toBe(401);
      expect(resPassIncorrecta.body.error).toBe("Credenciales inválidas");

      // Email inexistente
      const resEmailNoExiste = await request(app)
        .post("/api/auth/login")
        .send({
          email: "noexiste@demo.com",
          password: "Password123!",
        });

      expect(resEmailNoExiste.status).toBe(401);
      expect(resEmailNoExiste.body.error).toBe("Credenciales inválidas");
    });

    it("con usuario desactivado (estado: false) responde 401 'Usuario desactivado'", async () => {
      await crearUsuario({
        email: "desactivado@demo.com",
        password: "Password123!",
        estado: false,
      });

      const res = await request(app)
        .post("/api/auth/login")
        .send({
          email: "desactivado@demo.com",
          password: "Password123!",
        });

      expect(res.status).toBe(401);
      expect(res.body.error).toBe("Usuario desactivado");
    });
  });

  describe("GET /api/auth/perfil", () => {
    it("sin token responde 401 'No hay token en la petición'", async () => {
      const res = await request(app).get("/api/auth/perfil");
      expect(res.status).toBe(401);
      expect(res.body.error).toBe("No hay token en la petición");
    });

    it("con token inválido responde 401 'Token no válido o expirado'", async () => {
      const res = await request(app)
        .get("/api/auth/perfil")
        .set("x-token", "token-completamente-invalido");
      expect(res.status).toBe(401);
      expect(res.body.error).toBe("Token no válido o expirado");
    });

    it("con token válido responde 200 y devuelve el perfil del usuario", async () => {
      const usuario = await crearUsuario({
        nombre: "Ana Lopez",
        email: "ana.perfil@demo.com",
      });
      const token = await tokenUsuario(usuario);

      const res = await request(app)
        .get("/api/auth/perfil")
        .set("x-token", token);

      expect(res.status).toBe(200);
      expect(res.body.email).toBe("ana.perfil@demo.com");
      expect(res.body.uid).toBeDefined();
    });
  });

  describe("PUT /api/auth/perfil", () => {
    it("actualiza nombre y email del propio usuario con éxito (200)", async () => {
      const usuario = await crearUsuario({
        nombre: "Nombre Original",
        email: "original@demo.com",
      });
      const token = await tokenUsuario(usuario);

      const res = await request(app)
        .put("/api/auth/perfil")
        .set("x-token", token)
        .send({
          nombre: "Nombre Modificado",
          email: "original@demo.com",
        });

      expect(res.status).toBe(200);
      expect(res.body.nombre).toBe("Nombre Modificado");
    });

    it("responde 400 si intenta cambiarse a un email ya ocupado por otro", async () => {
      await crearUsuario({ email: "ocupado@demo.com" });
      const usuario2 = await crearUsuario({ email: "segundo@demo.com" });
      const token = await tokenUsuario(usuario2);

      const res = await request(app)
        .put("/api/auth/perfil")
        .set("x-token", token)
        .send({
          email: "ocupado@demo.com",
        });

      expect(res.status).toBe(400);
      expect(res.body.errores.some((e) => e.path === "email")).toBe(true);
    });
  });

  describe("PUT /api/auth/password", () => {
    it("con contraseña actual incorrecta responde 400", async () => {
      const token = await tokenUsuario({ password: "Password123!" });

      const res = await request(app)
        .put("/api/auth/password")
        .set("x-token", token)
        .send({
          passwordActual: "Incorrecta123!",
          passwordNueva: "NuevaPass123!",
        });

      expect(res.status).toBe(400);
      expect(res.body.error).toBe("La contraseña actual no es correcta");
    });

    it("con nueva contraseña igual a la actual responde 400", async () => {
      const token = await tokenUsuario({ password: "Password123!" });

      const res = await request(app)
        .put("/api/auth/password")
        .set("x-token", token)
        .send({
          passwordActual: "Password123!",
          passwordNueva: "Password123!",
        });

      expect(res.status).toBe(400);
      expect(res.body.error).toBe("La nueva contraseña debe ser distinta de la actual");
    });

    it("con cambio correcto responde 200 y luego el login funciona con la nueva contraseña", async () => {
      const email = "cambiopass@demo.com";
      const usuario = await crearUsuario({ email, password: "Password123!" });
      const token = await tokenUsuario(usuario);

      const resCambio = await request(app)
        .put("/api/auth/password")
        .set("x-token", token)
        .send({
          passwordActual: "Password123!",
          passwordNueva: "NuevaSegura123!",
        });

      expect(resCambio.status).toBe(200);
      expect(resCambio.body.mensaje).toBe("Contraseña actualizada");

      // Verificar que el login funciona con la nueva contraseña
      const resLogin = await request(app)
        .post("/api/auth/login")
        .send({
          email,
          password: "NuevaSegura123!",
        });

      expect(resLogin.status).toBe(200);
      expect(resLogin.body.token).toBeDefined();
    });
  });
});
