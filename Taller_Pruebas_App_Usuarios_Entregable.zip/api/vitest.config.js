import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    setupFiles: ["tests/setup.js"],
    env: {
      JWT_SECRET: "secreto-de-prueba-vitest-clave-super-segura-123456",
      JWT_EXPIRA: "2h",
      NODE_ENV: "test",
    },
    coverage: {
      provider: "v8",
      reporter: ["text", "html", "json-summary"],
      include: [
        "app.js",
        "controllers/**",
        "middlewares/**",
        "helpers/**",
        "models/**",
        "routes/**",
      ],
      thresholds: { lines: 80, functions: 80, statements: 80, branches: 70 },
    },
  },
});
