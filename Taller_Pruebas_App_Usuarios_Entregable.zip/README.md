# Taller de Pruebas de Software — App de Usuarios

Proyecto de aseguramiento de calidad y pruebas automatizadas (unitarias, integración, E2E y asistidas con IA) para la **App de Usuarios** (API REST con Node.js/Express y Web Frontend con Vue 3/Vite).

---

## 👥 Integrantes
* **Aprendiz / Desarrollador**: Jorge (ADSO - SENA)
* **Programa**: Tecnólogo en Análisis y Desarrollo de Software (ADSO)
* **Competencia**: Controlar la Calidad del Servicio de Software de Acuerdo con los Estándares Técnicos

---

## 📋 Requisitos Previos
* **Node.js**: Versión 22 o superior (`node -v`).
* **MongoDB**: Servicio de MongoDB local en marcha en el puerto `27017` (para la ejecución en modo desarrollo y pruebas E2E).
* **NPM**: Gestor de paquetes incluido con Node.js.

---

## 🚀 Instalación y Puesta en Marcha

### 1. Clonar o acceder al repositorio
```bash
cd app-usuarios
```

### 2. Configurar e Instalar Dependencias de la API (`api/`)
```bash
cd api
# Copiar variables de entorno si no existen
cp .env.example .env
npm install
# Cargar datos de prueba iniciales
npm run seed
```

### 3. Instalar Dependencias del Frontend (`web/`)
```bash
cd ../web
npm install
# Instalar navegadores para Playwright (Chromium y Firefox)
npx playwright install chromium firefox
```

---

## 🧪 Ejecución de Pruebas

### A. Pruebas de la API (`api/`)
Desde la carpeta `api/`:

* **Ejecutar todas las pruebas unitarias y de integración**:
  ```bash
  npm test
  ```
  *(Utiliza base de datos en memoria con `mongodb-memory-server`, sin afectar la base de datos real).*

* **Ejecutar pruebas en modo observador (watch)**:
  ```bash
  npm run test:watch
  ```

* **Generar reporte de cobertura (Coverage v8)**:
  ```bash
  npm run coverage
  ```
  *(Verifica los umbrales mínimos: 80% líneas, sentencias y funciones; 70% ramas).*

---

### B. Pruebas del Frontend Web (`web/`)
Desde la carpeta `web/`:

* **Ejecutar pruebas unitarias, de componentes y de guardas de router**:
  ```bash
  npm test
  ```

* **Ejecutar pruebas en modo observador (watch)**:
  ```bash
  npm run test:watch
  ```

* **Generar reporte de cobertura del frontend (Coverage v8)**:
  ```bash
  npm run coverage
  ```

---

### C. Pruebas End-to-End (E2E con Playwright)
Desde la carpeta `web/`:

* **Ejecutar flujos completos E2E en Chromium y Firefox**:
  ```bash
  npm run test:e2e
  ```
  *(Playwright levanta automáticamente la API en el puerto 3000 con la base de datos aislada `app-usuarios-e2e` y el frontend en el puerto 5173).*

* **Visualizar reporte interactivo HTML de Playwright**:
  ```bash
  npx playwright show-report
  ```

---

### D. Pruebas Asistidas por Inteligencia Artificial (TestSprite MCP)
1. Iniciar los servidores del proyecto:
   * En `api/`: `npm run seed && npm run dev` (puerto 3000).
   * En `web/`: `npm run dev` (puerto 5173).
2. Configurar el servidor MCP en el entorno (`~/.config` o archivo de configuración de IDE):
   ```json
   {
     "mcpServers": {
       "TestSprite": {
         "command": "npx",
         "args": ["@testsprite/testsprite-mcp@latest"],
         "env": { "API_KEY": "TU_API_KEY" }
       }
     }
   }
   ```
3. Ejecutar la auditoría cargando el archivo `PRD.md`.
4. Los reportes resultantes se encuentran archivados en `evidencias/testsprite/`.

---

## 📁 Estructura del Repositorio
```
app-usuarios/
├── api/                          # Backend Express + MongoDB
│   ├── app.js                    # Configuración y exportación de Express app
│   ├── server.js                 # Inicialización y listen() del servidor
│   ├── controllers/              # Controladores (auth, usuarios)
│   ├── database/                 # Conexión y script seed.js
│   ├── helpers/                  # Validadores y generador JWT
│   ├── middlewares/              # Middlewares de rol, jwt y campos
│   ├── models/                   # Modelo Mongoose (usuario.js)
│   ├── routes/                   # Rutas de la API
│   ├── tests/                    # Batería de pruebas con Vitest
│   │   ├── setup.js              # Configuración MongoMemoryServer
│   │   ├── helpers.js            # Helpers para tokens y usuarios
│   │   ├── unit/                 # Pruebas unitarias
│   │   └── integration/          # Pruebas de integración HTTP
│   └── vitest.config.js          # Configuración de Vitest y cobertura
├── web/                          # Frontend Vue 3 + Vite
│   ├── src/                      # Código fuente de componentes, vistas y composables
│   ├── tests/unit/               # Pruebas unitarias y componentes (Vue Test Utils)
│   ├── e2e/                      # Pruebas End-to-End con Playwright
│   ├── vitest.config.js          # Configuración Vitest frontend
│   └── playwright.config.js      # Configuración de Playwright E2E
├── evidencias/                   # Carpeta de reportes y evidencias
│   ├── coverage/                 # Resúmenes JSON de cobertura
│   ├── playwright/               # Reporte HTML de Playwright
│   └── testsprite/               # Reportes y planes de prueba de TestSprite
├── PRD.md                        # Documento de requisitos del producto
├── INFORME_PRUEBAS.md            # Informe final de análisis y resultados
└── README.md                     # Documentación general del proyecto
```

---

## 📊 Resumen de Resultados
* **Pruebas API**: 49 pruebas pasando (100%).
* **Pruebas Web**: 63 pruebas pasando (100%).
* **Pruebas E2E (Playwright)**: 16 pruebas pasando en Chromium y Firefox (100%).
* **Pruebas TestSprite (IA)**: 42 pruebas pasando en backend y frontend (100%).
* **Total de Pruebas**: **170 pruebas ejecutadas y aprobadas**.
* **Cobertura alcanzada**:
  * API: **89.3%** líneas / **83.5%** ramas (Supera los umbrales de 80%/70%).
  * Web: **88.0%** líneas / **79.7%** ramas (Supera los umbrales de 80%/70%).
