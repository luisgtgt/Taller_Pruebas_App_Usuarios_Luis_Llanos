import { describe, it, expect, vi, beforeEach } from 'vitest'
import router from '@/router/index.js'
import { useAuth } from '@/composables/useAuth.js'
import { tokenStorage } from '@/services/http.js'
import { authApi } from '@/services/authApi.js'

describe('Guardas del Router (router/index.js)', () => {
  beforeEach(() => {
    localStorage.clear()
    vi.restoreAllMocks()
    useAuth().logout()
  })

  it('redirecciona a /login si la ruta requiere autenticación y el usuario no ha iniciado sesión', async () => {
    await router.push('/perfil')
    expect(router.currentRoute.value.name).toBe('login')
    expect(router.currentRoute.value.query.redirect).toBe('/perfil')
  })

  it('redirecciona a /perfil si un usuario común intenta acceder a una ruta de admin (/usuarios)', async () => {
    const comunUser = { uid: 'u1', nombre: 'Usuario Común', rol: 'usuario' }
    vi.spyOn(authApi, 'perfil').mockResolvedValue(comunUser)
    tokenStorage.set('token-comun')

    await router.push('/usuarios')
    expect(router.currentRoute.value.name).toBe('profile')
  })

  it('permite acceder a /usuarios si el usuario es admin', async () => {
    const adminUser = { uid: 'u1', nombre: 'Admin', rol: 'admin' }
    vi.spyOn(authApi, 'perfil').mockResolvedValue(adminUser)
    tokenStorage.set('token-admin')

    await router.push('/usuarios')
    expect(router.currentRoute.value.name).toBe('users')
  })

  it('redirecciona a /home (que para admin es /usuarios) si intenta acceder a /login siendo usuario autenticado', async () => {
    const adminUser = { uid: 'u1', nombre: 'Admin', rol: 'admin' }
    vi.spyOn(authApi, 'perfil').mockResolvedValue(adminUser)
    tokenStorage.set('token-admin')

    await router.push('/login')
    expect(router.currentRoute.value.name).toBe('users')
  })

  it('actualiza el título del documento después de navegar', async () => {
    await router.push('/login')
    expect(document.title).toContain('Iniciar sesión')
  })
})
