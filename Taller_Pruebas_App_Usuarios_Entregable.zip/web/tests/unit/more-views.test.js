import { describe, it, expect, vi, beforeEach } from 'vitest'
import { mount, flushPromises } from '@vue/test-utils'
import { createRouter, createMemoryHistory } from 'vue-router'
import RegisterView from '@/views/RegisterView.vue'
import ProfileView from '@/views/ProfileView.vue'
import UsersView from '@/views/UsersView.vue'
import UserFormView from '@/views/UserFormView.vue'
import { useAuth } from '@/composables/useAuth.js'
import { authApi } from '@/services/authApi.js'
import { usersApi } from '@/services/usersApi.js'

describe('Vistas Adicionales de la Aplicación', () => {
  let router

  beforeEach(() => {
    localStorage.clear()
    vi.restoreAllMocks()

    router = createRouter({
      history: createMemoryHistory(),
      routes: [
        { path: '/', name: 'home', component: { template: '<div>Home</div>' } },
        { path: '/login', name: 'login', component: { template: '<div>Login</div>' } },
        { path: '/registro', name: 'register', component: RegisterView },
        { path: '/perfil', name: 'profile', component: ProfileView },
        { path: '/usuarios', name: 'users', component: UsersView },
        { path: '/usuarios/nuevo', name: 'user-create', component: UserFormView },
        { path: '/usuarios/:id/editar', name: 'user-edit', component: UserFormView, props: true },
      ],
    })
  })

  describe('RegisterView.vue', () => {
    it('muestra errores de validación si los campos son inválidos', async () => {
      const regSpy = vi.spyOn(authApi, 'registro')
      const wrapper = mount(RegisterView, {
        global: { plugins: [router] },
      })

      await wrapper.find('[data-test="register-form"]').trigger('submit.prevent')
      expect(regSpy).not.toHaveBeenCalled()
      expect(wrapper.text()).toContain('El nombre es obligatorio')
      expect(wrapper.text()).toContain('El email es obligatorio')
    })

    it('con datos válidos llama a register y navega a home', async () => {
      vi.spyOn(authApi, 'registro').mockResolvedValue({
        token: 'new-token',
        usuario: { uid: '123', nombre: 'Carlos Ruiz', rol: 'usuario' },
      })
      const pushSpy = vi.spyOn(router, 'push')

      const wrapper = mount(RegisterView, {
        global: { plugins: [router] },
      })

      await wrapper.find('[data-test="register-name"]').setValue('Carlos Ruiz')
      await wrapper.find('[data-test="register-email"]').setValue('carlos@demo.com')
      await wrapper.find('[data-test="register-password"]').setValue('Password123!')
      await wrapper.find('[data-test="register-confirmation"]').setValue('Password123!')
      await wrapper.find('[data-test="register-form"]').trigger('submit.prevent')

      await flushPromises()
      expect(pushSpy).toHaveBeenCalledWith({ name: 'home' })
    })
  })

  describe('ProfileView.vue', () => {
    beforeEach(() => {
      const auth = useAuth()
      auth.setUser({
        uid: 'u1',
        nombre: 'Admin Demo',
        email: 'admin@demo.com',
        rol: 'admin',
        createdAt: new Date().toISOString(),
      })
    })

    it('renderiza la información del perfil y rol', () => {
      const wrapper = mount(ProfileView, {
        global: { plugins: [router] },
      })

      expect(wrapper.find('[data-test="profile-role"]').text()).toBe('Administrador')
      expect(wrapper.find('[data-test="profile-name"]').element.value).toBe('Admin Demo')
      expect(wrapper.find('[data-test="profile-email"]').element.value).toBe('admin@demo.com')
    })

    it('actualiza los datos del perfil al enviar el formulario', async () => {
      const updateSpy = vi.spyOn(authApi, 'actualizarPerfil').mockResolvedValue({
        uid: 'u1',
        nombre: 'Admin Editado',
        email: 'admin.editado@demo.com',
        rol: 'admin',
        createdAt: new Date().toISOString(),
      })

      const wrapper = mount(ProfileView, {
        global: { plugins: [router] },
      })

      await wrapper.find('[data-test="profile-name"]').setValue('Admin Editado')
      await wrapper.find('[data-test="profile-email"]').setValue('admin.editado@demo.com')
      await wrapper.find('[data-test="profile-form"]').trigger('submit.prevent')

      expect(updateSpy).toHaveBeenCalledWith({
        nombre: 'Admin Editado',
        email: 'admin.editado@demo.com',
      })
    })

    it('actualiza la contraseña al enviar formulario con datos válidos', async () => {
      const changeSpy = vi.spyOn(authApi, 'cambiarPassword').mockResolvedValue({
        mensaje: 'Contraseña actualizada',
      })

      const wrapper = mount(ProfileView, {
        global: { plugins: [router] },
      })

      await wrapper.find('[data-test="password-current"]').setValue('Actual123!')
      await wrapper.find('[data-test="password-new"]').setValue('NuevaPass123!')
      await wrapper.find('[data-test="password-confirmation"]').setValue('NuevaPass123!')
      await wrapper.find('[data-test="password-form"]').trigger('submit.prevent')

      expect(changeSpy).toHaveBeenCalledWith({
        passwordActual: 'Actual123!',
        passwordNueva: 'NuevaPass123!',
      })
    })
  })

  describe('UsersView.vue', () => {
    it('carga usuarios y los renderiza en la tabla', async () => {
      vi.spyOn(usersApi, 'listar').mockResolvedValue({
        usuarios: [
          { uid: 'u1', nombre: 'Ana Torres', email: 'ana@demo.com', rol: 'usuario', createdAt: new Date().toISOString() },
          { uid: 'u2', nombre: 'Luis Perez', email: 'luis@demo.com', rol: 'admin', createdAt: new Date().toISOString() },
        ],
        total: 2,
        pagina: 1,
        limite: 8,
        totalPaginas: 1,
      })

      await router.push('/usuarios')
      const wrapper = mount(UsersView, {
        global: { plugins: [router] },
      })

      await flushPromises()
      expect(wrapper.text()).toContain('Ana Torres')
      expect(wrapper.text()).toContain('Luis Perez')
    })
  })

  describe('UserFormView.vue', () => {
    it('en modo creación envía datos con usersApi.crear', async () => {
      const createSpy = vi.spyOn(usersApi, 'crear').mockResolvedValue({ uid: 'new_u' })
      const pushSpy = vi.spyOn(router, 'push')

      const wrapper = mount(UserFormView, {
        props: { id: '' },
        global: { plugins: [router] },
      })

      await wrapper.find('[data-test="user-name"]').setValue('Nuevo Usuario')
      await wrapper.find('[data-test="user-email"]').setValue('nuevo@demo.com')
      await wrapper.find('[data-test="user-password"]').setValue('Password123!')
      await wrapper.find('[data-test="user-form"]').trigger('submit.prevent')

      await flushPromises()
      expect(createSpy).toHaveBeenCalled()
      expect(pushSpy).toHaveBeenCalledWith({ name: 'users' })
    })

    it('en modo edición carga datos del usuario con usersApi.obtener', async () => {
      vi.spyOn(usersApi, 'obtener').mockResolvedValue({
        uid: 'u100',
        nombre: 'Cargado Para Editar',
        email: 'cargado@demo.com',
        rol: 'usuario',
      })

      const wrapper = mount(UserFormView, {
        props: { id: 'u100' },
        global: { plugins: [router] },
      })

      await flushPromises()
      expect(wrapper.find('[data-test="user-name"]').element.value).toBe('Cargado Para Editar')
    })
  })
})
