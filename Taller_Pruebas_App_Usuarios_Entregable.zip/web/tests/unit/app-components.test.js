import { describe, it, expect, vi, beforeEach } from 'vitest'
import { mount } from '@vue/test-utils'
import { createRouter, createMemoryHistory } from 'vue-router'
import AppHeader from '@/components/AppHeader.vue'
import ToastContainer from '@/components/ToastContainer.vue'
import App from '@/App.vue'
import { useAuth } from '@/composables/useAuth.js'
import { useToast } from '@/composables/useToast.js'

describe('Componentes Estructurales (AppHeader, ToastContainer, App)', () => {
  let router

  beforeEach(() => {
    localStorage.clear()
    vi.restoreAllMocks()

    router = createRouter({
      history: createMemoryHistory(),
      routes: [
        { path: '/', name: 'home', component: { template: '<div>Home</div>' } },
        { path: '/login', name: 'login', component: { template: '<div>Login</div>' } },
        { path: '/usuarios', name: 'users', component: { template: '<div>Users</div>' } },
        { path: '/perfil', name: 'profile', component: { template: '<div>Profile</div>' } },
      ],
    })
  })

  describe('AppHeader.vue', () => {
    it('muestra las iniciales y nombre del usuario y navega a login al cerrar sesión', async () => {
      const auth = useAuth()
      auth.setUser({ uid: '1', nombre: 'Admin Demo', rol: 'admin' })
      const pushSpy = vi.spyOn(router, 'push')

      const wrapper = mount(AppHeader, {
        global: { plugins: [router] },
      })

      expect(wrapper.find('[data-test="current-user-name"]').text()).toBe('Admin Demo')
      expect(wrapper.find('.avatar').text()).toBe('AD')

      await wrapper.find('[data-test="logout"]').trigger('click')
      expect(pushSpy).toHaveBeenCalledWith({ name: 'login' })
    })
  })

  describe('ToastContainer.vue', () => {
    it('renderiza los toasts activos y permite cerrarlos', async () => {
      const toast = useToast()
      toast.success('Notificación 1')

      const wrapper = mount(ToastContainer)
      expect(wrapper.text()).toContain('Notificación 1')

      const closeBtn = wrapper.find('.toast__close')
      await closeBtn.trigger('click')
      expect(wrapper.text()).not.toContain('Notificación 1')
    })
  })

  describe('App.vue', () => {
    it('renderiza el contenedor principal y ToastContainer', () => {
      const wrapper = mount(App, {
        global: { plugins: [router] },
      })
      expect(wrapper.find('.layout').exists()).toBe(true)
    })
  })
})
