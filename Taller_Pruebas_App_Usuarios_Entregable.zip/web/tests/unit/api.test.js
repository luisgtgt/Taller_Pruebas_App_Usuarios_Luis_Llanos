import { describe, it, expect, vi, beforeEach } from 'vitest'
import { authApi } from '@/services/authApi.js'
import { usersApi } from '@/services/usersApi.js'
import * as http from '@/services/http.js'

describe('Servicios de API (authApi y usersApi)', () => {
  beforeEach(() => {
    vi.restoreAllMocks()
  })

  describe('authApi', () => {
    it('llama a los endpoints correctos con request()', async () => {
      const requestSpy = vi.spyOn(http, 'request').mockResolvedValue({ ok: true })

      await authApi.login({ email: 'a@demo.com', password: 'P1' })
      expect(requestSpy).toHaveBeenCalledWith('/auth/login', {
        method: 'POST',
        body: { email: 'a@demo.com', password: 'P1' },
      })

      await authApi.registro({ nombre: 'A', email: 'a@demo.com', password: 'P1' })
      expect(requestSpy).toHaveBeenCalledWith('/auth/registro', {
        method: 'POST',
        body: { nombre: 'A', email: 'a@demo.com', password: 'P1' },
      })

      await authApi.perfil()
      expect(requestSpy).toHaveBeenCalledWith('/auth/perfil')

      await authApi.actualizarPerfil({ nombre: 'B' })
      expect(requestSpy).toHaveBeenCalledWith('/auth/perfil', {
        method: 'PUT',
        body: { nombre: 'B' },
      })

      await authApi.cambiarPassword({ passwordActual: 'P1', passwordNueva: 'P2' })
      expect(requestSpy).toHaveBeenCalledWith('/auth/password', {
        method: 'PUT',
        body: { passwordActual: 'P1', passwordNueva: 'P2' },
      })
    })
  })

  describe('usersApi', () => {
    it('llama a los endpoints CRUD con los parámetros y métodos correctos', async () => {
      const requestSpy = vi.spyOn(http, 'request').mockResolvedValue({ ok: true })

      await usersApi.listar({ buscar: 'ana', rol: 'admin', pagina: 1, limite: 10 })
      expect(requestSpy).toHaveBeenCalledWith('/usuarios', {
        query: { buscar: 'ana', rol: 'admin', pagina: 1, limite: 10 },
      })

      await usersApi.obtener('u123')
      expect(requestSpy).toHaveBeenCalledWith('/usuarios/u123')

      await usersApi.crear({ nombre: 'Nuevo' })
      expect(requestSpy).toHaveBeenCalledWith('/usuarios', {
        method: 'POST',
        body: { nombre: 'Nuevo' },
      })

      await usersApi.actualizar('u123', { nombre: 'Actualizado' })
      expect(requestSpy).toHaveBeenCalledWith('/usuarios/u123', {
        method: 'PUT',
        body: { nombre: 'Actualizado' },
      })

      await usersApi.eliminar('u123')
      expect(requestSpy).toHaveBeenCalledWith('/usuarios/u123', {
        method: 'DELETE',
      })
    })
  })
})
