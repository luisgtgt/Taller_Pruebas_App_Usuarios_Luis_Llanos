import { describe, it, expect } from 'vitest'
import {
  validateName,
  validateEmail,
  validatePassword,
  validatePasswordConfirmation,
  isValid,
} from '@/utils/validators.js'

describe('Validador de cliente (validators.js)', () => {
  describe('validateName', () => {
    it('retorna error si el nombre está vacío o tiene solo espacios', () => {
      expect(validateName('')).toBe('El nombre es obligatorio')
      expect(validateName('   ')).toBe('El nombre es obligatorio')
    })

    it('retorna error si el nombre tiene menos de 2 caracteres', () => {
      expect(validateName('A')).toBe('El nombre debe tener entre 2 y 60 caracteres')
    })

    it('retorna error si el nombre tiene más de 60 caracteres', () => {
      const largo = 'A'.repeat(61)
      expect(validateName(largo)).toBe('El nombre debe tener entre 2 y 60 caracteres')
    })

    it('retorna cadena vacía para un nombre válido', () => {
      expect(validateName('Juan Perez')).toBe('')
    })
  })

  describe('validateEmail', () => {
    it('retorna error si el email está vacío', () => {
      expect(validateEmail('')).toBe('El email es obligatorio')
      expect(validateEmail('   ')).toBe('El email es obligatorio')
    })

    it('retorna error si el email no tiene formato válido', () => {
      expect(validateEmail('invalido')).toBe('El email no tiene un formato válido')
      expect(validateEmail('sin@dominio')).toBe('El email no tiene un formato válido')
      expect(validateEmail('@sinusuario.com')).toBe('El email no tiene un formato válido')
    })

    it('retorna cadena vacía para un email válido', () => {
      expect(validateEmail('usuario@demo.com')).toBe('')
    })
  })

  describe('validatePassword', () => {
    it('retorna error si la contraseña está vacía', () => {
      expect(validatePassword('')).toBe('La contraseña es obligatoria')
    })

    it('retorna error si tiene menos de 8 caracteres', () => {
      expect(validatePassword('Ab1!')).toBe('La contraseña debe tener entre 8 y 64 caracteres')
    })

    it('retorna error si tiene más de 64 caracteres', () => {
      const muyLarga = 'A'.repeat(65) + 'a1'
      expect(validatePassword(muyLarga)).toBe('La contraseña debe tener entre 8 y 64 caracteres')
    })

    it('retorna error si no incluye al menos una mayúscula', () => {
      expect(validatePassword('minuscula123!')).toBe('La contraseña debe incluir al menos una mayúscula')
    })

    it('retorna error si no incluye al menos una minúscula', () => {
      expect(validatePassword('MAYUSCULA123!')).toBe('La contraseña debe incluir al menos una minúscula')
    })

    it('retorna error si no incluye al menos un número', () => {
      expect(validatePassword('SoloLetrasMayusYMin')).toBe('La contraseña debe incluir al menos un número')
    })

    it('retorna cadena vacía para una contraseña válida', () => {
      expect(validatePassword('Password123!')).toBe('')
    })
  })

  describe('validatePasswordConfirmation', () => {
    it('retorna error si la confirmación está vacía', () => {
      expect(validatePasswordConfirmation('Password123!', '')).toBe('Repite la contraseña')
    })

    it('retorna error si las contraseñas no coinciden', () => {
      expect(validatePasswordConfirmation('Password123!', 'OtraPass123!')).toBe('Las contraseñas no coinciden')
    })

    it('retorna cadena vacía si las contraseñas coinciden', () => {
      expect(validatePasswordConfirmation('Password123!', 'Password123!')).toBe('')
    })
  })

  describe('isValid', () => {
    it('retorna true cuando no hay mensajes de error', () => {
      expect(isValid({ email: '', password: '', nombre: '' })).toBe(true)
    })

    it('retorna false si al menos un campo tiene un mensaje de error', () => {
      expect(isValid({ email: '', password: 'La contraseña es obligatoria' })).toBe(false)
    })
  })
})
