import { describe, it, expect, vi, beforeEach } from 'vitest'
import { mount } from '@vue/test-utils'
import { createRouter, createMemoryHistory } from 'vue-router'
import LoginView from '@/views/LoginView.vue'
import NotFoundView from '@/views/NotFoundView.vue'
import { authApi } from '@/services/authApi.js'

describe('Vistas (Views)', () => {
  let router

  beforeEach(() => {
    localStorage.clear()
    vi.restoreAllMocks()

    router = createRouter({
      history: createMemoryHistory(),
      routes: [
        { path: '/', name: 'home', component: { template: '<div>Home</div>' } },
        { path: '/login', name: 'login', component: LoginView },
        { path: '/registro', name: 'register', component: { template: '<div>Registro</div>' } },
      ],
    })
  })

  describe('LoginView.vue', () => {
    it('con email inválido muestra el error sin llamar a la API', async () => {
      const loginSpy = vi.spyOn(authApi, 'login')

      const wrapper = mount(LoginView, {
        global: {
          plugins: [router],
        },
      })

      // Formulario con email inválido
      await wrapper.find('[data-test="login-email"]').setValue('email-invalido')
      await wrapper.find('[data-test="login-password"]').setValue('Password123!')
      await wrapper.find('[data-test="login-form"]').trigger('submit.prevent')

      expect(loginSpy).not.toHaveBeenCalled()
      const errorEmail = wrapper.find('[data-test="login-email-error"]')
      expect(errorEmail.exists()).toBe(true)
      expect(errorEmail.text()).toBe('El email no tiene un formato válido')
    })

    it('con error del servidor muestra el alert', async () => {
      vi.spyOn(authApi, 'login').mockRejectedValue(new Error('Credenciales inválidas'))

      const wrapper = mount(LoginView, {
        global: {
          plugins: [router],
        },
      })

      await wrapper.find('[data-test="login-email"]').setValue('admin@demo.com')
      await wrapper.find('[data-test="login-password"]').setValue('PasswordErronea123!')
      await wrapper.find('[data-test="login-form"]').trigger('submit.prevent')

      await wrapper.vm.$nextTick()
      await new Promise((resolve) => setTimeout(resolve, 50))

      const alert = wrapper.find('[data-test="alert"]')
      expect(alert.exists()).toBe(true)
      expect(alert.text()).toBe('Credenciales inválidas')
    })

    it('con credenciales correctas llama a la API y navega', async () => {
      vi.spyOn(authApi, 'login').mockResolvedValue({
        token: 'token-valido',
        usuario: { uid: '1', nombre: 'Admin', rol: 'admin' },
      })
      const pushSpy = vi.spyOn(router, 'push')

      const wrapper = mount(LoginView, {
        global: {
          plugins: [router],
        },
      })

      await wrapper.find('[data-test="login-email"]').setValue('admin@demo.com')
      await wrapper.find('[data-test="login-password"]').setValue('Admin123!')
      await wrapper.find('[data-test="login-form"]').trigger('submit.prevent')

      await new Promise((resolve) => setTimeout(resolve, 50))

      expect(pushSpy).toHaveBeenCalledWith({ name: 'home' })
    })
  })

  describe('NotFoundView.vue', () => {
    it('renderiza el mensaje de página no encontrada', () => {
      const wrapper = mount(NotFoundView, {
        global: {
          plugins: [router],
        },
      })
      expect(wrapper.text()).toContain('Página no encontrada')
    })
  })
})
