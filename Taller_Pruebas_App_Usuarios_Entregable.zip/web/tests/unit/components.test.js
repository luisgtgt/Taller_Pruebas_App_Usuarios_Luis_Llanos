import { describe, it, expect, beforeEach } from 'vitest'
import { mount } from '@vue/test-utils'
import FormField from '@/components/FormField.vue'
import PaginationBar from '@/components/PaginationBar.vue'
import ConfirmDialog from '@/components/ConfirmDialog.vue'
import AlertMessage from '@/components/AlertMessage.vue'

describe('Componentes de interfaz (Vue Test Utils)', () => {
  beforeEach(() => {
    document.body.innerHTML = ''
  })

  describe('FormField.vue', () => {
    it('muestra el error con data-test {testId}-error', () => {
      const wrapper = mount(FormField, {
        props: {
          label: 'Email',
          testId: 'user-email',
          error: 'Email inválido',
        },
      })

      const errorEl = wrapper.find('[data-test="user-email-error"]')
      expect(errorEl.exists()).toBe(true)
      expect(errorEl.text()).toBe('Email inválido')
    })

    it('el botón Mostrar/Ocultar cambia el tipo de input de password a text', async () => {
      const wrapper = mount(FormField, {
        props: {
          label: 'Contraseña',
          type: 'password',
          testId: 'user-password',
        },
      })

      const input = wrapper.find('input')
      expect(input.attributes('type')).toBe('password')

      const toggleBtn = wrapper.find('[data-test="user-password-toggle"]')
      expect(toggleBtn.exists()).toBe(true)
      expect(toggleBtn.text()).toBe('Mostrar')

      await toggleBtn.trigger('click')
      expect(input.attributes('type')).toBe('text')
      expect(toggleBtn.text()).toBe('Ocultar')

      await toggleBtn.trigger('click')
      expect(input.attributes('type')).toBe('password')
    })

    it('actualiza el valor a través de v-model', async () => {
      const wrapper = mount(FormField, {
        props: {
          label: 'Nombre',
          modelValue: 'Carlos',
          'onUpdate:modelValue': (e) => wrapper.setProps({ modelValue: e }),
        },
      })

      const input = wrapper.find('input')
      await input.setValue('Carlos Alberto')
      expect(wrapper.emitted('update:modelValue')[0]).toEqual(['Carlos Alberto'])
    })
  })

  describe('PaginationBar.vue', () => {
    it('muestra el texto Mostrando X–Y de Z y deshabilita botones en límites', async () => {
      const wrapper = mount(PaginationBar, {
        props: { page: 1, totalPages: 3, total: 20, limit: 8 },
      })

      const info = wrapper.find('[data-test="pagination-info"]')
      expect(info.text()).toContain('Mostrando 1–8 de 20')

      const prevBtn = wrapper.find('[data-test="pagination-prev"]')
      const nextBtn = wrapper.find('[data-test="pagination-next"]')

      expect(prevBtn.attributes('disabled')).toBeDefined()
      expect(nextBtn.attributes('disabled')).toBeUndefined()

      await nextBtn.trigger('click')
      expect(wrapper.emitted('change')[0]).toEqual([2])
    })

    it('en la última página deshabilita Siguiente y permite Anterior', async () => {
      const wrapper = mount(PaginationBar, {
        props: { page: 3, totalPages: 3, total: 20, limit: 8 },
      })

      const prevBtn = wrapper.find('[data-test="pagination-prev"]')
      const nextBtn = wrapper.find('[data-test="pagination-next"]')

      expect(nextBtn.attributes('disabled')).toBeDefined()
      expect(prevBtn.attributes('disabled')).toBeUndefined()

      await prevBtn.trigger('click')
      expect(wrapper.emitted('change')[0]).toEqual([2])
    })
  })

  describe('ConfirmDialog.vue', () => {
    it('emite confirm y cancel con los botones confirm-accept y confirm-cancel', async () => {
      mount(ConfirmDialog, {
        props: {
          open: true,
          title: 'Confirmar eliminación',
          message: '¿Seguro que deseas eliminar este usuario?',
        },
        attachTo: document.body,
      })

      const acceptBtn = document.body.querySelector('[data-test="confirm-accept"]')
      const cancelBtn = document.body.querySelector('[data-test="confirm-cancel"]')

      expect(acceptBtn).not.toBeNull()
      expect(cancelBtn).not.toBeNull()
      expect(document.body.textContent).toContain('Confirmar eliminación')
    })
  })

  describe('AlertMessage.vue', () => {
    it('no renderiza contenido si message está vacío', () => {
      const wrapper = mount(AlertMessage, {
        props: { message: '' },
      })
      expect(wrapper.find('[data-test="alert"]').exists()).toBe(false)
    })

    it('renderiza el mensaje y la clase correspondiente', () => {
      const wrapper = mount(AlertMessage, {
        props: { message: 'Mensaje de error', type: 'error' },
      })
      const alert = wrapper.find('[data-test="alert"]')
      expect(alert.exists()).toBe(true)
      expect(alert.text()).toBe('Mensaje de error')
      expect(alert.classes()).toContain('alert--error')
    })
  })
})
