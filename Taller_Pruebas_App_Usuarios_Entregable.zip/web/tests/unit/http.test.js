import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
import {
  request,
  ApiError,
  tokenStorage,
  setUnauthorizedHandler,
} from '@/services/http.js'

describe('Servicio HTTP (http.js)', () => {
  beforeEach(() => {
    localStorage.clear()
    vi.restoreAllMocks()
  })

  afterEach(() => {
    vi.unstubAllGlobals()
  })

  it('envía el header x-token si hay token guardado en localStorage', async () => {
    tokenStorage.set('mi-token-secreto')

    const mockFetch = vi.fn().mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({ ok: true }),
    })
    vi.stubGlobal('fetch', mockFetch)

    await request('/test')

    expect(mockFetch).toHaveBeenCalledTimes(1)
    const callArgs = mockFetch.mock.calls[0]
    expect(callArgs[1].headers['x-token']).toBe('mi-token-secreto')
  })

  it('no envía el header x-token si no hay token guardado', async () => {
    const mockFetch = vi.fn().mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({ ok: true }),
    })
    vi.stubGlobal('fetch', mockFetch)

    await request('/test')

    const callArgs = mockFetch.mock.calls[0]
    expect(callArgs[1].headers['x-token']).toBeUndefined()
  })

  it('serializa el body como JSON y agrega Content-Type: application/json', async () => {
    const mockFetch = vi.fn().mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({ id: 1 }),
    })
    vi.stubGlobal('fetch', mockFetch)

    const payload = { nombre: 'Juan', email: 'juan@demo.com' }
    await request('/usuarios', { method: 'POST', body: payload })

    expect(mockFetch).toHaveBeenCalledTimes(1)
    const options = mockFetch.mock.calls[0][1]
    expect(options.method).toBe('POST')
    expect(options.headers['Content-Type']).toBe('application/json')
    expect(options.body).toBe(JSON.stringify(payload))
  })

  it('adjunta query parameters correctamente en la URL', async () => {
    const mockFetch = vi.fn().mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({}),
    })
    vi.stubGlobal('fetch', mockFetch)

    await request('/usuarios', { query: { rol: 'admin', buscar: 'ana' } })

    const url = mockFetch.mock.calls[0][0].toString()
    expect(url).toContain('rol=admin')
    expect(url).toContain('buscar=ana')
  })

  it('convierte { errores: [...] } en ApiError con details por campo', async () => {
    const mockFetch = vi.fn().mockResolvedValue({
      ok: false,
      status: 400,
      json: async () => ({
        errores: [
          { path: 'email', msg: 'Email inválido' },
          { path: 'password', msg: 'Muy corta' },
        ],
      }),
    })
    vi.stubGlobal('fetch', mockFetch)

    await expect(request('/registro', { method: 'POST', body: {} })).rejects.toThrow(ApiError)

    try {
      await request('/registro', { method: 'POST', body: {} })
    } catch (err) {
      expect(err).toBeInstanceOf(ApiError)
      expect(err.status).toBe(400)
      expect(err.details).toEqual({
        email: 'Email inválido',
        password: 'Muy corta',
      })
    }
  })

  it('convierte { error } en ApiError con ese mensaje general', async () => {
    const mockFetch = vi.fn().mockResolvedValue({
      ok: false,
      status: 401,
      json: async () => ({ error: 'Credenciales inválidas' }),
    })
    vi.stubGlobal('fetch', mockFetch)

    try {
      await request('/auth/login', { method: 'POST' })
    } catch (err) {
      expect(err).toBeInstanceOf(ApiError)
      expect(err.status).toBe(401)
      expect(err.message).toBe('Credenciales inválidas')
    }
  })

  it('si fetch falla lanza ApiError con status 0 y mensaje de conexión', async () => {
    const mockFetch = vi.fn().mockRejectedValue(new Error('Network error'))
    vi.stubGlobal('fetch', mockFetch)

    try {
      await request('/cualquier-ruta')
      expect.unreachable()
    } catch (err) {
      expect(err).toBeInstanceOf(ApiError)
      expect(err.status).toBe(0)
      expect(err.message).toContain('No se pudo conectar con el servidor')
    }
  })

  it('con respuesta 401 y token guardado llama al manejador de setUnauthorizedHandler', async () => {
    tokenStorage.set('token-expirado')

    const mockFetch = vi.fn().mockResolvedValue({
      ok: false,
      status: 401,
      json: async () => ({ error: 'Token expirado' }),
    })
    vi.stubGlobal('fetch', mockFetch)

    const onUnauthorizedMock = vi.fn()
    setUnauthorizedHandler(onUnauthorizedMock)

    await expect(request('/usuarios')).rejects.toThrow(ApiError)
    expect(onUnauthorizedMock).toHaveBeenCalledTimes(1)
  })
})
