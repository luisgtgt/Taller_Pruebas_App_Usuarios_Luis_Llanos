import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
import { useToast } from '@/composables/useToast.js'
import { useAuth } from '@/composables/useAuth.js'
import { tokenStorage } from '@/services/http.js'
import { authApi } from '@/services/authApi.js'

describe('Composables (useToast y useAuth)', () => {
  beforeEach(() => {
    localStorage.clear()
    vi.restoreAllMocks()
  })

  describe('useToast', () => {
    beforeEach(() => {
      vi.useFakeTimers()
    })

    afterEach(() => {
      vi.useRealTimers()
    })

    it('success agrega un toast y se elimina automáticamente al pasar el tiempo', () => {
      const { toasts, success } = useToast()
      const initialCount = toasts.length

      success('Operación exitosa')
      expect(toasts.length).toBe(initialCount + 1)
      const ultimo = toasts[toasts.length - 1]
      expect(ultimo.message).toBe('Operación exitosa')
      expect(ultimo.type).toBe('success')

      // Avanzar temporizadores 3500ms
      vi.advanceTimersByTime(3500)
      expect(toasts.some((t) => t.id === ultimo.id)).toBe(false)
    })

    it('error agrega un toast con duración mayor (5000ms) y se elimina automáticamente', () => {
      const { toasts, error } = useToast()
      error('Ocurrió un error grave')

      const ultimo = toasts[toasts.length - 1]
      expect(ultimo.message).toBe('Ocurrió un error grave')
      expect(ultimo.type).toBe('error')

      vi.advanceTimersByTime(3500)
      // Todavía existe a los 3500ms
      expect(toasts.some((t) => t.id === ultimo.id)).toBe(true)

      vi.advanceTimersByTime(1500) // Completa 5000ms
      expect(toasts.some((t) => t.id === ultimo.id)).toBe(false)
    })

    it('dismiss elimina manualmente un toast por su id', () => {
      const { toasts, success, dismiss } = useToast()
      const id = success('Toast para borrar')

      expect(toasts.some((t) => t.id === id)).toBe(true)
      dismiss(id)
      expect(toasts.some((t) => t.id === id)).toBe(false)
    })
  })

  describe('useAuth', () => {
    it('login guarda token, usuario y actualiza isAuthenticated e isAdmin', async () => {
      const fakeUser = { uid: 'u123', nombre: 'Admin', email: 'admin@demo.com', rol: 'admin' }
      vi.spyOn(authApi, 'login').mockResolvedValue({
        token: 'token-jwt-admin',
        usuario: fakeUser,
      })

      const auth = useAuth()
      await auth.login({ email: 'admin@demo.com', password: 'Password123!' })

      expect(tokenStorage.get()).toBe('token-jwt-admin')
      expect(auth.isAuthenticated.value).toBe(true)
      expect(auth.isAdmin.value).toBe(true)
      expect(auth.state.user.nombre).toBe('Admin')
    })

    it('logout borra el token de localStorage y limpia el estado de autenticación', () => {
      const auth = useAuth()
      auth.logout()

      expect(tokenStorage.get()).toBeNull()
      expect(auth.isAuthenticated.value).toBe(false)
      expect(auth.isAdmin.value).toBe(false)
      expect(auth.state.user).toBeNull()
    })

    it('restoreSession recupera los datos del usuario si hay un token válido', async () => {
      tokenStorage.set('token-existente')
      const fakeProfile = { uid: 'u456', nombre: 'Usuario Común', rol: 'usuario' }
      vi.spyOn(authApi, 'perfil').mockResolvedValue(fakeProfile)

      const auth = useAuth()
      auth.clearSession()
      tokenStorage.set('token-existente')

      await auth.restoreSession(true)

      expect(auth.state.user).toEqual(fakeProfile)
      expect(auth.isAdmin.value).toBe(false)
      expect(auth.isAuthenticated.value).toBe(true)
    })
  })
})
