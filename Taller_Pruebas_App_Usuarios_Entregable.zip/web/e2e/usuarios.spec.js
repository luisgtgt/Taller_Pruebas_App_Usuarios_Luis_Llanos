import { test, expect } from '@playwright/test';
import { loginAsAdmin } from './helpers.js';

test.describe('CRUD de Usuarios y Paginación E2E', () => {
  test.beforeEach(async ({ page }) => {
    await loginAsAdmin(page);
  });

  test('El admin crea un usuario, lo encuentra con el buscador (users-search) y lo edita', async ({ page }) => {
    const timestamp = Date.now();
    const nombreOriginal = `Usuario Test ${timestamp}`;
    const emailOriginal = `test_crud_${timestamp}@demo.com`;
    const nombreEditado = `Usuario Modificado ${timestamp}`;

    // 1. Crear nuevo usuario
    await page.getByTestId('users-new').click();
    await expect(page).toHaveURL(/\/usuarios\/nuevo/);

    await page.getByTestId('user-name').fill(nombreOriginal);
    await page.getByTestId('user-email').fill(emailOriginal);
    await page.getByTestId('user-password').fill('PasswordSegura123!');
    await page.getByTestId('user-role').selectOption('usuario');
    await page.getByTestId('user-submit').click();

    await expect(page).toHaveURL(/\/usuarios$/);

    // 2. Buscar con users-search
    await page.getByTestId('users-search').fill(nombreOriginal);
    const row = page.getByTestId('user-row').first();
    await expect(row).toBeVisible();
    await expect(row).toContainText(nombreOriginal);

    // 3. Editar usuario
    await row.getByTestId('user-edit').click();
    await expect(page).toHaveURL(/\/usuarios\/.*\/editar/);

    await page.getByTestId('user-name').fill(nombreEditado);
    await page.getByTestId('user-submit').click();

    await expect(page).toHaveURL(/\/usuarios$/);

    // 4. Verificar cambio
    await page.getByTestId('users-search').fill(nombreEditado);
    await expect(page.getByTestId('user-row').first()).toContainText(nombreEditado);
  });

  test('El admin elimina un usuario con el diálogo de confirmación y ese usuario ya no puede iniciar sesión', async ({ page }) => {
    const timestamp = Date.now();
    const emailBorrar = `borrar_${timestamp}@demo.com`;
    const passBorrar = 'PasswordSegura123!';

    // Crear usuario para borrar
    await page.getByTestId('users-new').click();
    await page.getByTestId('user-name').fill(`Para Borrar ${timestamp}`);
    await page.getByTestId('user-email').fill(emailBorrar);
    await page.getByTestId('user-password').fill(passBorrar);
    await page.getByTestId('user-submit').click();
    await expect(page).toHaveURL(/\/usuarios$/);

    // Buscarlo y hacer click en eliminar
    await page.getByTestId('users-search').fill(emailBorrar);
    const row = page.getByTestId('user-row').first();
    await expect(row).toContainText(emailBorrar);

    await row.getByTestId('user-delete').click();
    await expect(page.getByTestId('confirm-accept')).toBeVisible();
    await page.getByTestId('confirm-accept').click();

    // Confirmar que ya no aparece en el listado
    await expect(page.getByTestId('users-empty')).toBeVisible();

    // Comprobar que ya no puede iniciar sesión
    await page.getByTestId('logout').click();
    await page.goto('/login');
    await page.getByTestId('login-email').fill(emailBorrar);
    await page.getByTestId('login-password').fill(passBorrar);
    await page.getByTestId('login-submit').click();

    await expect(page.getByTestId('alert')).toBeVisible();
    await expect(page.getByTestId('alert')).toContainText('Usuario desactivado');
  });

  test('Filtro por rol y paginación: el texto de pagination-info cambia al ir a la página siguiente', async ({ page, request }) => {
    // Para asegurar que existen más de 8 usuarios (límite de página), creamos usuarios adicionales
    const token = await page.evaluate(() => localStorage.getItem('x-token'));
    for (let i = 1; i <= 6; i++) {
      await request.post('http://localhost:3000/api/usuarios', {
        headers: { 'x-token': token },
        data: {
          nombre: `Paginado ${Date.now()}_${i}`,
          email: `paginado_${Date.now()}_${i}@demo.com`,
          password: 'Password123!',
          rol: 'usuario',
        },
      });
    }

    await page.goto('/usuarios');
    await expect(page.getByTestId('pagination-info')).toBeVisible();
    const textoInicial = await page.getByTestId('pagination-info').innerText();
    expect(textoInicial).toContain('1–8 de');

    // Cambiar a la página 2
    await page.getByTestId('pagination-next').click();
    await expect(page.getByTestId('pagination-info')).toContainText('9–');

    // Probar filtro por rol
    await page.getByTestId('users-role-filter').selectOption('admin');
    await expect(page.getByTestId('user-row').first()).toContainText('Administrador');
  });
});
