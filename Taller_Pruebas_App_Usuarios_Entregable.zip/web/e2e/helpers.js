export async function loginAsAdmin(page) {
  await page.goto('/login');
  await page.getByTestId('login-email').fill('admin@demo.com');
  await page.getByTestId('login-password').fill('Admin123!');
  await page.getByTestId('login-submit').click();
  await page.waitForURL(/\/usuarios/);
}

export async function loginAsUser(page) {
  await page.goto('/login');
  await page.getByTestId('login-email').fill('ana@demo.com');
  await page.getByTestId('login-password').fill('Usuario123');
  await page.getByTestId('login-submit').click();
  await page.waitForURL(/\/perfil/);
}
