import { test, expect } from '@playwright/test';
import { loginAsUser } from './helpers.js';

test.describe('Flujos de Autenticación y Navegación E2E', () => {
  test('Login con credenciales incorrectas: aparece el alert con "Credenciales inválidas" y se sigue en /login', async ({ page }) => {
    await page.goto('/login');
    await page.getByTestId('login-email').fill('admin@demo.com');
    await page.getByTestId('login-password').fill('ContraseñaErronea123!');
    await page.getByTestId('login-submit').click();

    await expect(page.getByTestId('alert')).toBeVisible();
    await expect(page.getByTestId('alert')).toContainText('Credenciales inválidas');
    expect(page.url()).toContain('/login');
  });

  test('Registro de una cuenta nueva: entra a /perfil y el rol mostrado es Usuario', async ({ page }) => {
    const randomSuffix = Date.now();
    const emailNuevo = `nuevo_${randomSuffix}@demo.com`;

    await page.goto('/registro');
    await page.getByTestId('register-name').fill(`Usuario Nuevo ${randomSuffix}`);
    await page.getByTestId('register-email').fill(emailNuevo);
    await page.getByTestId('register-password').fill('PasswordSegura123!');
    await page.getByTestId('register-confirmation').fill('PasswordSegura123!');
    await page.getByTestId('register-submit').click();

    await expect(page).toHaveURL(/\/perfil/);
    await expect(page.getByTestId('profile-role')).toHaveText('Usuario');
  });

  test('Un usuario con rol usuario que abre /usuarios es redirigido a /perfil; sin sesión, /usuarios redirige a /login', async ({ page }) => {
    // 1. Sin sesión: /usuarios redirige a /login
    await page.goto('/usuarios');
    await expect(page).toHaveURL(/\/login/);

    // 2. Con rol usuario: /usuarios redirige a /perfil
    await loginAsUser(page);
    await page.goto('/usuarios');
    await expect(page).toHaveURL(/\/perfil/);
  });

  test('El usuario cambia su contraseña desde el perfil, cierra sesión (logout) e inicia sesión con la nueva', async ({ page }) => {
    // Registramos un usuario específico para cambiar su contraseña
    const timestamp = Date.now();
    const email = `cambio_${timestamp}@demo.com`;
    const passwordOriginal = 'ClaveOriginal123!';
    const passwordNueva = 'ClaveNueva123!';

    await page.goto('/registro');
    await page.getByTestId('register-name').fill(`User Cambio ${timestamp}`);
    await page.getByTestId('register-email').fill(email);
    await page.getByTestId('register-password').fill(passwordOriginal);
    await page.getByTestId('register-confirmation').fill(passwordOriginal);
    await page.getByTestId('register-submit').click();
    await expect(page).toHaveURL(/\/perfil/);

    // Cambiar contraseña en el perfil
    await page.getByTestId('password-current').fill(passwordOriginal);
    await page.getByTestId('password-new').fill(passwordNueva);
    await page.getByTestId('password-confirmation').fill(passwordNueva);
    await page.getByTestId('password-submit').click();

    // Notificación toast de éxito específica del cambio de contraseña
    await expect(page.getByTestId('toast').filter({ hasText: 'Contraseña actualizada' })).toBeVisible();

    // Cerrar sesión
    await page.getByTestId('logout').click();
    await expect(page).toHaveURL(/\/login/);

    // Iniciar sesión con la contraseña nueva
    await page.getByTestId('login-email').fill(email);
    await page.getByTestId('login-password').fill(passwordNueva);
    await page.getByTestId('login-submit').click();
    await expect(page).toHaveURL(/\/perfil/);
  });

  test('Una ruta que no existe muestra la página de "no encontrada"', async ({ page }) => {
    await page.goto('/esta-ruta-no-existe-nunca-12345');
    await expect(page.getByRole('heading', { level: 1 })).toContainText('Página no encontrada');
  });
});
