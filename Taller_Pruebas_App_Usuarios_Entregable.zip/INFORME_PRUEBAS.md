# Informe Final de Pruebas de Software — App de Usuarios

**Programa de Formación**: Tecnólogo en Análisis y Desarrollo de Software (ADSO) — SENA  
**Competencia**: Controlar la Calidad del Servicio de Software de Acuerdo con los Estándares Técnicos  
**Proyecto**: Taller de Pruebas de Software – App de Usuarios (API REST y Web Frontend)  
**Herramientas Utilizadas**: Vitest, Supertest, Vue Test Utils, Playwright, @vitest/coverage-v8 y TestSprite (MCP)

---

## 1. Resumen Ejecutivo por Proyecto y Tipo de Prueba

A continuación se detalla la matriz global de pruebas automatizadas ejecutadas tanto en el Backend (`api/`) como en el Frontend (`web/`), cumpliendo y superando ampliamente el umbral exigido de mínimo 30 pruebas por proyecto:

| Proyecto | Tipo de Prueba | Herramienta | Pruebas Ejecutadas | Pruebas Aprobadas (Pass) | Pruebas Fallidas (Fail) | % Cobertura (Líneas / Ramas) |
| :--- | :--- | :--- | :---: | :---: | :---: | :---: |
| **API** | Unitarias (Middlewares, Helpers, Modelo) | Vitest | 15 | 15 | 0 | 89.3% / 83.5% |
| **API** | Integración HTTP (Auth y CRUD Usuarios) | Supertest + MongoMemoryServer | 34 | 34 | 0 | 89.3% / 83.5% |
| **API (Total)** | *Subtotal Backend* | **Vitest + Supertest** | **49** | **49** | **0** | **89.3% (Líneas) / 83.5% (Ramas)** |
| **Web** | Unitarias (Validadores, HTTP, Composables) | Vitest + jsdom | 35 | 35 | 0 | 88.0% / 79.7% |
| **Web** | Componentes y Vistas | Vue Test Utils | 23 | 23 | 0 | 88.0% / 79.7% |
| **Web** | Guardas de Navegación del Router | Vitest + Vue Router | 5 | 5 | 0 | 88.0% / 79.7% |
| **Web (Total)** | *Subtotal Frontend* | **Vitest + Vue Test Utils** | **63** | **63** | **0** | **88.0% (Líneas) / 79.7% (Ramas)** |
| **E2E** | End-to-End Integrado (Chromium y Firefox) | Playwright | 16 | 16 | 0 | N/A (Flujos Reales) |
| **IA** | Pruebas Asistidas con IA (Backend API) | TestSprite (MCP) | 24 | 24 | 0 | N/A (Caja Negra) |
| **IA** | Pruebas Asistidas con IA (Frontend Web) | TestSprite (MCP) | 18 | 18 | 0 | N/A (Caja Negra) |
| **TOTAL GENERAL** | **Batería Completa de Pruebas** | — | **170** | **170** | **0** | **Todos los umbrales superados** |

---

## 2. Análisis del Reporte de Cobertura (Coverage)

Los reportes de cobertura se obtuvieron empleando `@vitest/coverage-v8` para ambos proyectos con umbrales mínimos requeridos:
* **Líneas (Lines)**: $\ge 80\%$
* **Sentencias (Statements)**: $\ge 80\%$
* **Funciones (Functions)**: $\ge 80\%$
* **Ramas (Branches)**: $\ge 70\%$

### 2.1. Métricas Obtenidas vs Umbrales

| Métrica | Umbral Mínimo Exigido | Resultado API (`api/`) | Resultado Web (`web/`) | Estado |
| :--- | :---: | :---: | :---: | :---: |
| **Lines (Líneas)** | 80% | **89.30%** | **88.00%** | **CUMPLIDO (+9.3% / +8.0%)** |
| **Statements (Sentencias)** | 80% | **88.83%** | **87.01%** | **CUMPLIDO (+8.8% / +7.0%)** |
| **Functions (Funciones)** | 80% | **96.96%** | **81.56%** | **CUMPLIDO (+17.0% / +1.6%)** |
| **Branches (Ramas)** | 70% | **83.52%** | **79.72%** | **CUMPLIDO (+13.5% / +9.7%)** |

### 2.2. Análisis de Líneas Sin Cubrir (Líneas en Rojo) y Justificación

#### En Backend (`api/`):
* **`app.js` (Líneas 19-20 y 55-56)**: Corresponden al middleware de registro por consola (`console.log`) que se desactiva deliberadamente bajo entorno de pruebas (`process.env.NODE_ENV === 'test'`) para no ensuciar la salida de terminal, y a la captura de fallos internos no controlados (`500 Error interno`). Las líneas no cubiertas son rutas de excepción extrema (como pérdida total de conexión con base de datos en tiempo de ejecución).
* **`controllers/auth.js` y `controllers/usuarios.js` (Líneas de `next(error)`)**: Las líneas de captura `catch (error) { next(error); }` se reservan para fallas imprevistas de drivers o corrupción de memoria en Mongoose, las cuales no se activan bajo condiciones estándar de validación.

#### En Frontend (`web/`):
* **`src/components/ConfirmDialog.vue` (Líneas 19-27 y 53-62)**: La navegación de accesibilidad mediante el listener de teclado `Escape` (`onKeydown`) y el autofoco en el botón de cancelar tras la animación de transición no se evalúan en jsdom (que no procesa renderizado de layouts ni transiciones CSS). Sin embargo, este flujo se validó en las pruebas E2E con navegadores reales mediante Playwright.
* **`src/views/UsersView.vue` (Líneas 188-219)**: Funciones de reintento manual por fallo de red cuando la API deja de responder estando la vista ya abierta.

---

## 3. Errores y Comportamientos Dudosos Encontrados y Soluciones

Gracias al diseño riguroso y automatización de pruebas, se descubrieron y corrigieron comportamientos defectuosos en el código base original:

### Hallazgo 1: Manejo de estado defectuoso en `restoreSession` (`web/src/composables/useAuth.js`)
* **Comportamiento Anómalo**: La función `clearSession()` asignaba `state.loaded = true`. Como consecuencia, cuando un usuario cerraba sesión o la aplicación intentaba reinicializarse con nuevas credenciales, `restoreSession()` abortaba de inmediato debido a la condición `if (state.loaded) return`, impidiendo validar o restablecer la sesión activa contra el endpoint `/api/auth/perfil`.
* **Impacto**: Bloqueo del ciclo de vida de autenticación e inconsistencias en la redirección de las guardas de rutas.
* **Solución Implementada**: Se ajustó `clearSession()` para restablecer `state.loaded = false` y se sincronizó reactivamente `state.token = tokenStorage.get()` al inicio de `restoreSession()`, permitiendo un flujo limpio y consistente.

### Hallazgo 2: Riesgo de `TypeError: Cannot read properties of undefined` en vistas con formularios (`ProfileView.vue` y `RegisterView.vue`)
* **Comportamiento Anómalo**: Al procesar excepciones del servicio HTTP en los formularios, el código inspeccionaba directamente `if (Object.keys(error.details).length)` o `if (error.details.passwordNueva)` sin verificar si `error.details` estaba definido. Cuando ocurría un error general del servidor (como un código 500 o fallo de conexión con status 0 donde `details` no se suministra), el frontend lanzaba un `TypeError` no controlado, interrumpiendo la ejecución del script.
* **Impacto**: Caída de la interfaz de usuario en lugar de presentar amigablemente el mensaje al usuario en el componente `AlertMessage`.
* **Solución Implementada**: Se protegió la lectura aplicando encadenamiento opcional (`error.details?.passwordNueva`) y comprobando la existencia de la propiedad antes de extraer sus claves.

### Hallazgo 3: Carrera asíncrona en detección de Notificaciones Toast en E2E
* **Comportamiento Anómalo**: Al ejecutar flujos concatenados de Registro y Cambio de Contraseña en pruebas E2E, el selector `getByTestId('toast')` colisionaba con el toast persistente de bienvenida (`¡Cuenta creada! Bienvenido.`), haciendo clic prematuramente en logout antes de que la petición de cambio de contraseña fuera procesada en la base de datos.
* **Solución Implementada**: Se refinó la espera en Playwright mediante localizadores específicos: `page.getByTestId('toast').filter({ hasText: 'Contraseña actualizada' })`.

---

## 4. Pruebas End-to-End (Playwright)

Se implementaron y ejecutaron 16 pruebas E2E en dos navegadores reales (**Chromium** y **Firefox**) ejecutándose de forma aislada sobre la base de datos de pruebas `app-usuarios-e2e`.

* **Navegadores validados**:
  * Chromium: 8/8 pruebas aprobadas (100%).
  * Firefox: 8/8 pruebas aprobadas (100%).
* **Flujos cubiertos**:
  1. Login fallido con alerta de credenciales inválidas.
  2. Registro de cuenta nueva y verificación de rol Usuario en perfil.
  3. Protección de rutas y redirecciones automáticas por rol (usuario común a perfil, sin sesión a login).
  4. Alta de usuario por administrador, localización reactiva con `users-search` y edición.
  5. Eliminación lógica mediante modal accesible `ConfirmDialog` y comprobación de bloqueo de login posterior.
  6. Paginación con más de 8 usuarios, cambio dinámico de información en `pagination-info` y filtro por rol.
  7. Cambio de contraseña en perfil, logout y re-login exitoso con la nueva clave.
  8. Enrutamiento hacia página de error 404 ante rutas no registradas.

---

## 5. Pruebas Asistidas con Inteligencia Artificial (TestSprite MCP)

### 5.1. Configuración Realizada
Se integró el servidor MCP oficial de TestSprite (`@testsprite/testsprite-mcp`) y se utilizó el documento `PRD.md` con las especificaciones técnicas completas del sistema.

### 5.2. Tabla de Análisis de Fallos en TestSprite

| Caso | Componente | Descripción | Resultado 1ª Ejecución | Causa Raíz | Decisión / Solución en 2ª Ejecución |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **TC-API-007** | Backend (`api/`) | Admin degrada su propio rol a 'usuario' mediante `PUT /api/usuarios/:id` | Falló: Esperaba 200 OK | Requisito mal interpretado por la IA: asumió que el admin podía editar cualquier campo de cualquier cuenta. La regla de negocio prohíbe explícitamente auto-modificar el rol propio (400). | Se precisó la regla en el `PRD.md`. En la segunda corrida, TestSprite esperó el código 400 y el test pasó exitosamente. |
| **TC-WEB-005** | Frontend (`web/`) | Validación de discrepancia entre contraseña y confirmación en registro | Falló: Esperaba notificación tipo Toast | Suposición errónea del agente IA: esperaba que la discordancia mostrara un toast flotante, cuando la aplicación muestra el error inline en `register-confirmation-error`. | Se documentó la especificación de errores inline de `FormField` en el PRD. Pasó exitosamente en la segunda ejecución. |

### 5.3. Comparativa: Pruebas Escritas a Mano vs. Pruebas con TestSprite (IA)

> La integración de **TestSprite** demostró ser un complemento de alto valor para el ciclo de aseguramiento de calidad (QA). Mientras que las **pruebas manuales tradicionales (escritas por el desarrollador)** son deterministas, rápidas de ejecutar en entornos de Integración Continua (CI) y permiten un control granular y exhaustivo sobre funciones internas, mocks, temporizadores virtuales (`vi.useFakeTimers`) y bases de datos en memoria, las pruebas generadas por **TestSprite con IA** destacan por su capacidad de explorar flujos de caja negra imprevistos, generar casos de prueba basados en lenguaje natural y someter la API y la interfaz a combinaciones de datos que el desarrollador suele omitir por sesgo de confirmación. Sin embargo, TestSprite requiere un PRD sumamente riguroso para evitar falsos positivos derivados de malas interpretaciones de reglas de negocio específicas (como la prohibición de auto-eliminación o degradación de rol). El enfoque ideal radica en un modelo híbrido: pruebas unitarias, de integración y E2E escritas con Vitest y Playwright como red de seguridad obligatoria del pipeline de desarrollo, complementadas con auditorías periódicas de TestSprite para descubrir brechas funcionales en las interfaces públicas.

---

## 6. Organización de Evidencias

Todas las evidencias y artefactos generados se encuentran estructurados en la carpeta `evidencias/`:
* **Cobertura (`evidencias/coverage/`)**:
  * `api-coverage-summary.json`: Reporte cuantitativo de cobertura de la API.
  * `web-coverage-summary.json`: Reporte cuantitativo de cobertura del frontend.
* **Playwright E2E (`evidencias/playwright/`)**:
  * `playwright-report.html`: Reporte HTML detallado con trazabilidad de ejecución en Chromium y Firefox.
* **TestSprite (`evidencias/testsprite/`)**:
  * `api/TestSprite_MCP_Test_Report.md`: Reporte de auditoría backend de TestSprite.
  * `api/testsprite_tests/test_plan.json`: Plan de pruebas backend generado.
  * `web/TestSprite_MCP_Test_Report.md`: Reporte de auditoría frontend de TestSprite.
  * `web/testsprite_tests/test_plan.json`: Plan de pruebas frontend generado.
